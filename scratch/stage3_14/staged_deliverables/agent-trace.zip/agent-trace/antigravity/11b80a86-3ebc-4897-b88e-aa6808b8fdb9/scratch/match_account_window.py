import pandas as pd
import json

sample_reqs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_deletion_requests.csv')
sample_outs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_output.csv')
sys_act = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/system_activity.csv')

primary_acts = sys_act[sys_act['details'].str.contains('primary profile account_', na=False)].copy()

merged = pd.merge(sample_reqs, sample_outs, on='case_id')

for idx, r in merged.iterrows():
    cid = r['case_id']
    steps = json.loads(r['steps_json'])
    acc_steps = [s['resource_id'] for s in steps if s['system_id'] == 'account_service']
    expected_acc = acc_steps[0] if acc_steps else None
    
    # find primary acts in window
    t_start = r['requested_at']
    t_end = r['reported_at']
    sub = primary_acts[(primary_acts['event_time'] >= t_start) & (primary_acts['event_time'] <= t_end)]
    
    matched_in_sub = expected_acc in sub['resource_id'].tolist() if expected_acc else None
    print(f"{cid}: expected={expected_acc} | window_candidates={sub['resource_id'].tolist()} | in_window={matched_in_sub}")
