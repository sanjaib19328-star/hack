import os
import csv

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

with open(os.path.join(DATASET_DIR, "system_activity.csv"), "r", encoding="utf-8") as f:
    sys_acts = list(csv.DictReader(f))

print("=== CLASSIFY_REQUEST ===")
for a in sys_acts:
    if a["event_type"] == "CLASSIFY_REQUEST":
        print(a)

print("\n=== RESTORE_BACKUP ===")
for a in sys_acts:
    if a["event_type"] == "RESTORE_BACKUP":
        print(a)

print("\n=== LINK_RESOURCE_IDENTITY ===")
for a in sys_acts:
    if a["event_type"] == "LINK_RESOURCE_IDENTITY":
        print(a)
