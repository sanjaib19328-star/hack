import pandas as pd
import json

sample_reqs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_deletion_requests.csv')
sample_outs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_output.csv')
users = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/user_identities.csv')
audit_log = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/user_audit_log.csv')
sys_act = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/system_activity.csv')

email_to_uid = {}
for idx, r in users.iterrows():
    email_to_uid[r['email'].lower()] = r['user_id']
for idx, r in audit_log.iterrows():
    if pd.notna(r['old_value']) and '@' in str(r['old_value']):
        email_to_uid[str(r['old_value']).lower()] = r['user_id']
    if pd.notna(r['new_value']) and '@' in str(r['new_value']):
        email_to_uid[str(r['new_value']).lower()] = r['user_id']

merged = pd.merge(sample_reqs, sample_outs, on='case_id')

for idx, r in merged.iterrows():
    uid = email_to_uid[r['email'].lower()]
    steps = json.loads(r['steps_json'])
    out_resources = set(s['resource_id'] for s in steps)
    
    # Check resources in system_activity for this user
    user_act = sys_act[sys_act['user_id'] == uid]
    act_resources = set(user_act['resource_id'].dropna())
    
    missing_in_act = out_resources - act_resources
    extra_in_act = act_resources - out_resources
    print(f"{r['case_id']} ({uid}): out_res={len(out_resources)}, act_res={len(act_resources)} | missing={missing_in_act} | extra={extra_in_act}")
