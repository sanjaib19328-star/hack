import csv
import json
import os
import re
from collections import defaultdict
import pandas as pd

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
OUTPUT_CSV = os.path.join(REPO_DIR, "output.csv")
INPUT_CSV = os.path.join(REPO_DIR, "dataset", "deletion_requests.csv")
EVIDENCE_CSV = os.path.join(REPO_DIR, "dataset", "evidence_files.csv")

# 1. Check file existence
assert os.path.exists(OUTPUT_CSV), "output.csv does not exist!"
print("output.csv exists.")

# 2. Check input vs output row counts
input_cases = []
with open(INPUT_CSV, "r", encoding="utf-8") as f:
    input_cases = [r["case_id"] for r in csv.DictReader(f)]

assert len(input_cases) == 518, f"Expected 518 input cases, found {len(input_cases)}"
print(f"Verified {len(input_cases)} input cases.")

# 3. Check manifest of evidence files
with open(EVIDENCE_CSV, "r", encoding="utf-8") as f:
    valid_evidence_ids = {r["file_id"] for r in csv.DictReader(f)}
print(f"Loaded {len(valid_evidence_ids)} valid evidence file IDs.")

# 4. Check schema, header, values
VALID_STATUSES = {"COMPLETE", "INCOMPLETE", "NOT_APPLICABLE"}
VALID_PHASES = {"FINDING", "REMEDIATION", "VERIFICATION"}
VALID_SYSTEMS = {
    "account_service", "search_service", "analytics_platform",
    "support_platform", "integration_service", "backup_service",
    "security_service", "identity_service", "export_service"
}

OP_ORDER = {
    "FINDING": {
        "REPORT_REMAINING_RECORD": 1,
        "REPORT_EXPOSED_PII": 2,
        "REPORT_ACTIVE_DATA_FLOW": 3,
        "REPORT_RESTORE_RISK": 4
    },
    "REMEDIATION": {
        "DISABLE_DATA_FLOW": 1,
        "BLOCK_RESTORE": 2,
        "DELETE_RECORD": 3,
        "REDACT_RECORD": 4,
        "ANONYMIZE_RECORD": 5
    },
    "VERIFICATION": {
        "VERIFY_RECORD_ABSENT": 1,
        "VERIFY_RECORD_PRESENT": 2,
        "VERIFY_RECORD_REDACTED": 3,
        "VERIFY_RECORD_ANONYMIZED": 4,
        "VERIFY_DATA_FLOW_DISABLED": 5,
        "VERIFY_RESTORE_BLOCKED": 6
    }
}
PHASE_ORDER = {"FINDING": 1, "REMEDIATION": 2, "VERIFICATION": 3}

output_rows = []
with open(OUTPUT_CSV, "r", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    assert reader.fieldnames == ["case_id", "deletion_status", "steps_json"], f"Invalid header: {reader.fieldnames}"
    for r in reader:
        output_rows.append(r)

assert len(output_rows) == 518, f"Expected 518 output rows, found {len(output_rows)}"
print(f"Verified exactly 518 output rows with exact header case_id,deletion_status,steps_json.")

# 5. Check row-by-row consistency
output_cids = set()
status_counts = defaultdict(int)

for idx, r in enumerate(output_rows):
    cid = r["case_id"]
    status = r["deletion_status"]
    steps_raw = r["steps_json"]
    
    assert cid not in output_cids, f"Duplicate case_id: {cid}"
    output_cids.add(cid)
    assert cid == input_cases[idx], f"Order mismatch at row {idx}: expected {input_cases[idx]}, got {cid}"
    
    assert status in VALID_STATUSES, f"Invalid status: {status} in case {cid}"
    status_counts[status] += 1
    
    # Parse JSON
    try:
        steps = json.loads(steps_raw)
    except Exception as ex:
        raise AssertionError(f"Failed to parse steps_json for {cid}: {ex}")
    
    assert isinstance(steps, list), f"steps_json is not an array in {cid}"
    
    if status == "NOT_APPLICABLE":
        assert len(steps) == 0, f"NOT_APPLICABLE case {cid} has non-empty steps: {len(steps)}"
    elif status == "COMPLETE":
        assert len(steps) > 0, f"COMPLETE case {cid} has empty steps"
        for i, s in enumerate(steps, 1):
            assert s["step_no"] == i, f"{cid}: step_no {s['step_no']} != {i}"
            assert s["phase"] == "VERIFICATION", f"{cid}: COMPLETE case has phase {s['phase']}"
            assert s["system_id"] in VALID_SYSTEMS, f"{cid}: invalid system {s['system_id']}"
            assert s["operation"] in OP_ORDER[s["phase"]], f"{cid}: invalid operation {s['operation']}"
            assert s["evidence_id"] in valid_evidence_ids, f"{cid}: invalid evidence_id {s['evidence_id']}"
    elif status == "INCOMPLETE":
        assert len(steps) > 0, f"INCOMPLETE case {cid} has empty steps"
        has_finding = False
        for i, s in enumerate(steps, 1):
            assert s["step_no"] == i, f"{cid}: step_no {s['step_no']} != {i}"
            assert s["phase"] in VALID_PHASES, f"{cid}: invalid phase {s['phase']}"
            assert s["system_id"] in VALID_SYSTEMS, f"{cid}: invalid system {s['system_id']}"
            assert s["operation"] in OP_ORDER[s["phase"]], f"{cid}: invalid operation {s['operation']}"
            if s["phase"] == "FINDING":
                has_finding = True
                assert s["evidence_id"] in valid_evidence_ids, f"{cid}: finding has invalid evidence_id {s['evidence_id']}"
            else:
                assert s["evidence_id"] == "", f"{cid}: {s['phase']} has non-empty evidence_id: {s['evidence_id']}"
        assert has_finding, f"INCOMPLETE case {cid} has no findings"

    # Verify step sorting
    for i in range(len(steps) - 1):
        s1, s2 = steps[i], steps[i+1]
        k1 = (PHASE_ORDER[s1["phase"]], OP_ORDER[s1["phase"]][s1["operation"]], s1["system_id"], s1["resource_id"])
        k2 = (PHASE_ORDER[s2["phase"]], OP_ORDER[s2["phase"]][s2["operation"]], s2["system_id"], s2["resource_id"])
        assert k1 <= k2, f"{cid}: ordering violation between step {s1['step_no']} and {s2['step_no']}"

print(f"\nAll 518 cases passed 100% of validation assertions!")
print(f"Status distribution:")
for st, cnt in sorted(status_counts.items()):
    print(f"  {st:15s}: {cnt}")
