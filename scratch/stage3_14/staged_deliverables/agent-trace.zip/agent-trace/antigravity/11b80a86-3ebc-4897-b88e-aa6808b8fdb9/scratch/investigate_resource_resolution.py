"""
Investigation script: Ground-truth resource and identity resolution across all evidence sources.
"""

import os
import glob
import re
import json
import csv
from collections import defaultdict

repo_dir = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
dataset_dir = os.path.join(repo_dir, "dataset")

# 1. Identity Resolver
email_to_uid = {}
uid_to_emails = defaultdict(set)
uid_to_names = defaultdict(set)
uid_to_phones = defaultdict(set)

with open(os.path.join(dataset_dir, "user_identities.csv"), encoding="utf-8") as f:
    for r in csv.DictReader(f):
        u = r["user_id"]
        e = r["email"].lower().strip()
        email_to_uid[e] = u
        uid_to_emails[u].add(e)
        if r.get("phone"): uid_to_phones[u].add(r["phone"].strip())
        if r.get("name"): uid_to_names[u].add(r["name"].lower().strip())

with open(os.path.join(dataset_dir, "user_audit_log.csv"), encoding="utf-8") as f:
    for r in csv.DictReader(f):
        u = r["user_id"]
        fn = r.get("field_name")
        if fn == "email":
            if r.get("old_value"):
                e = r["old_value"].lower().strip()
                email_to_uid[e] = u
                uid_to_emails[u].add(e)
            if r.get("new_value"):
                e = r["new_value"].lower().strip()
                email_to_uid[e] = u
                uid_to_emails[u].add(e)

print(f"Loaded identities: {len(uid_to_emails)} users, {len(email_to_uid)} emails.")

# 2. Extract mappings from ALL evidence sources
# We want to map: user_key (user_id or email) -> {system_id: {resource_id: ...}}
user_resources = defaultdict(lambda: defaultdict(set))
res_to_user = {}

# A. system_activity.csv: LINK_RESOURCE_IDENTITY
with open(os.path.join(dataset_dir, "system_activity.csv"), encoding="utf-8") as f:
    for r in csv.DictReader(f):
        if r["event_type"] == "LINK_RESOURCE_IDENTITY":
            res = r["resource_id"]
            sys_id = r["target_system"]
            details = r["details"]
            # e.g. Data catalog linked account_5762 (account_5762) to haruka.s1838@zoho.com and user_11.
            m_uid = re.search(r"user_\d+", details)
            m_email = re.search(r"[\w\.-]+@[\w\.-]+", details)
            u = m_uid.group(0) if m_uid else None
            e = m_email.group(0).lower() if m_email else None
            if u:
                user_resources[u][sys_id].add(res)
                res_to_user[res] = u
            if e and e in email_to_uid:
                u2 = email_to_uid[e]
                user_resources[u2][sys_id].add(res)
                res_to_user[res] = u2

# B. SQL dumps: customer_profiles, customer_search_documents, support_records, backup_restore_entries, etc.
for fpath in glob.glob(os.path.join(dataset_dir, "**", "*.sql"), recursive=True):
    with open(fpath, encoding="utf-8", errors="ignore") as f:
        for line in f:
            if "INSERT INTO" not in line:
                continue
            # Extract quoted strings or values
            tokens = re.findall(r"'([^']*)'", line)
            if not tokens:
                continue
            res = tokens[0]
            # Match user references or emails in tokens
            found_u = None
            for tok in tokens[1:]:
                if tok.startswith("user_") and tok in uid_to_emails:
                    found_u = tok
                    break
                tok_lower = tok.lower()
                if tok_lower in email_to_uid:
                    found_u = email_to_uid[tok_lower]
                    break
            if found_u and res:
                res_to_user[res] = found_u
                # Determine system
                if "customer_profiles" in line: sys_id = "account_service"
                elif "customer_search" in line: sys_id = "search_service"
                elif "analytics" in line: sys_id = "analytics_platform"
                elif "support" in line: sys_id = "support_platform"
                elif "export" in line: sys_id = "export_service"
                elif "connector" in line: sys_id = "integration_service"
                elif "backup" in line: sys_id = "backup_service"
                elif "security" in line: sys_id = "security_service"
                else: sys_id = "unknown"
                user_resources[found_u][sys_id].add(res)

# C. JSON Snapshot Bundles & Service Exports
for fpath in glob.glob(os.path.join(dataset_dir, "**", "*.json"), recursive=True):
    try:
        with open(fpath, encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        continue
    
    # 1. Snapshot bundles
    if "snapshots" in data:
        for snap in data["snapshots"]:
            sys_id = snap.get("data_store")
            for rec in snap.get("records", []):
                res = rec.get("resource_id")
                u = rec.get("customer_reference") or rec.get("user_id") or rec.get("subject_reference")
                e = (rec.get("email") or rec.get("owner_email") or rec.get("requester_email") or "").lower().strip()
                found_u = None
                if u and u.startswith("user_"):
                    found_u = u
                elif e and e in email_to_uid:
                    found_u = email_to_uid[e]
                if found_u and res and sys_id:
                    user_resources[found_u][sys_id].add(res)
                    res_to_user[res] = found_u

    # 2. Service resource exports
    if "service_exports" in data:
        for sys_id, content in data["service_exports"].items():
            if isinstance(content, dict):
                for k, v in content.items():
                    if isinstance(v, list):
                        for item in v:
                            res = item.get("resource_id")
                            u = item.get("customer_reference") or item.get("subject_reference") or item.get("user_id")
                            e = (item.get("email") or item.get("customer_email") or item.get("requester_email") or item.get("query") or "").lower().strip()
                            found_u = None
                            if u and str(u).startswith("user_"):
                                found_u = str(u)
                            elif e and e in email_to_uid:
                                found_u = email_to_uid[e]
                            if found_u and res:
                                user_resources[found_u][sys_id].add(res)
                                res_to_user[res] = found_u

# D. Readback trace logs & Handover text
for fpath in glob.glob(os.path.join(dataset_dir, "**", "resource_lookup_trace*.log"), recursive=True):
    with open(fpath, encoding="utf-8", errors="ignore") as f:
        for line in f:
            m_res = re.search(r"resource_id=(\w+)", line)
            m_u = re.search(r"(?:customer_reference|subject_reference|lookup_key)=\"?([^\s\",]+)\"?", line)
            m_sys = re.search(r"service=(\w+)", line)
            if m_res and m_u and m_sys:
                res = m_res.group(1)
                u_str = m_u.group(1)
                sys_id = m_sys.group(1)
                found_u = None
                if u_str.startswith("user_"):
                    found_u = u_str
                elif u_str.lower() in email_to_uid:
                    found_u = email_to_uid[u_str.lower()]
                if found_u and res:
                    user_resources[found_u][sys_id].add(res)
                    res_to_user[res] = found_u

# Check coverage against sample_output.csv
with open(os.path.join(dataset_dir, "sample_output.csv"), encoding="utf-8") as f:
    sample_out = {r["case_id"]: json.loads(r["steps_json"]) for r in csv.DictReader(f)}

with open(os.path.join(dataset_dir, "sample_deletion_requests.csv"), encoding="utf-8") as f:
    sample_reqs = {r["case_id"]: r for r in csv.DictReader(f)}

total_steps = 0
matched_resources = 0
unmatched_list = []

for cid, steps in sample_out.items():
    req = sample_reqs[cid]
    u = email_to_uid.get(req["email"].lower().strip())
    for s in steps:
        total_steps += 1
        res = s["resource_id"]
        sys_id = s["system_id"]
        if u and res in user_resources[u][sys_id]:
            matched_resources += 1
        elif res in res_to_user:
            matched_resources += 1
        else:
            unmatched_list.append((cid, u, sys_id, res, s["operation"]))

print(f"\nResource Resolution Evaluation:")
print(f"Total steps in sample ground truth: {total_steps}")
print(f"Matched resources: {matched_resources} ({matched_resources/total_steps*100:.2f}%)")
print(f"Unmatched resources count: {len(unmatched_list)}")
for item in unmatched_list[:15]:
    print("  Unmatched:", item)
