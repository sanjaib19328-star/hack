import csv
import json
import os
from collections import defaultdict

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

# Load sample requests
with open(os.path.join(DATASET_DIR, "sample_deletion_requests.csv"), "r", encoding="utf-8") as f:
    sample_reqs = {r["case_id"]: r for r in csv.DictReader(f)}

# Load sample outputs
with open(os.path.join(DATASET_DIR, "sample_output.csv"), "r", encoding="utf-8") as f:
    sample_outs = {r["case_id"]: (r["deletion_status"], json.loads(r["steps_json"])) for r in csv.DictReader(f)}

with open(os.path.join(DATASET_DIR, "user_identities.csv"), "r", encoding="utf-8") as f:
    user_identities = list(csv.DictReader(f))

with open(os.path.join(DATASET_DIR, "user_audit_log.csv"), "r", encoding="utf-8") as f:
    user_audit = list(csv.DictReader(f))

with open(os.path.join(DATASET_DIR, "system_activity.csv"), "r", encoding="utf-8") as f:
    system_activity = list(csv.DictReader(f))

with open(os.path.join(DATASET_DIR, "evidence_files.csv"), "r", encoding="utf-8") as f:
    evidence_manifest = list(csv.DictReader(f))

# Identity resolution
email_to_uid = {}
uid_to_emails = defaultdict(set)
uid_to_names = defaultdict(set)
uid_to_phones = defaultdict(set)

for u in user_identities:
    uid = u["user_id"]
    e = u["email"].lower()
    email_to_uid[e] = uid
    uid_to_emails[uid].add(e)
    if u.get("name"): uid_to_names[uid].add(u["name"].lower())
    if u.get("phone"): uid_to_phones[uid].add(u["phone"])

for a in user_audit:
    uid = a["user_id"]
    if a["field_name"] == "email":
        email_to_uid[a["old_value"].lower()] = uid
        uid_to_emails[uid].add(a["old_value"].lower())
        uid_to_emails[uid].add(a["new_value"].lower())
    elif a["field_name"] == "phone":
        uid_to_phones[uid].add(a["old_value"])
        uid_to_phones[uid].add(a["new_value"])
    elif a["field_name"] == "name":
        uid_to_names[uid].add(a["old_value"].lower())
        uid_to_names[uid].add(a["new_value"].lower())

print("Testing resource discovery across sample cases...")

# Inspect cases 11-20 (the mid cases)
for cid in [f"case_{i:02d}" for i in range(11, 21)]:
    req = sample_reqs[cid]
    status, steps = sample_outs[cid]
    uid = email_to_uid.get(req["email"].lower())
    expected_res = set(s["resource_id"] for s in steps)
    print(f"\n{cid} ({uid}, email={req['email']}, audit_at={req['audit_at']}):")
    print(f"  Expected resources: {sorted(expected_res)}")
    # Where did they appear?
    for s in steps:
        print(f"    {s['phase']:12s} {s['system_id']:20s} {s['resource_id']:20s} {s['operation']:25s} {s['state']:12s} ev={s['evidence_id']}")
