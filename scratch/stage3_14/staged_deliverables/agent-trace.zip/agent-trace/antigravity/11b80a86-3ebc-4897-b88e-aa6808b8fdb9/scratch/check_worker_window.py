import pandas as pd
import json

sample_reqs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_deletion_requests.csv')
sample_outs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_output.csv')
sys_act = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/system_activity.csv')

# Only consider worker activities: DELETE_RECORD, ANONYMIZE_RECORD, REDACT_RECORD, DISABLE_DATA_FLOW, BLOCK_RESTORE
worker_ops = {'DELETE_RECORD', 'ANONYMIZE_RECORD', 'REDACT_RECORD', 'DISABLE_DATA_FLOW', 'BLOCK_RESTORE'}

worker_acts = sys_act[sys_act['event_type'].isin(worker_ops)].copy()

merged = pd.merge(sample_reqs, sample_outs, on='case_id')

all_matched = 0
for idx, r in merged.iterrows():
    cid = r['case_id']
    t_start = r['requested_at']
    t_end = r['reported_at']
    
    # window
    sub_acts = worker_acts[(worker_acts['event_time'] >= t_start) & (worker_acts['event_time'] <= t_end)]
    
    steps = json.loads(r['steps_json'])
    out_resources = set(s['resource_id'] for s in steps)
    act_resources = set(sub_acts['resource_id'])
    
    common = out_resources & act_resources
    print(f"{cid} ({r['email']}): out={len(out_resources)}, window_acts={len(act_resources)}, intersection={len(common)}")
    if out_resources - common:
        print(f"   Missing from window: {out_resources - common}")
