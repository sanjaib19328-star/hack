import os

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

for root, dirs, files in os.walk(DATASET_DIR):
    for f in files:
        fpath = os.path.join(root, f)
        try:
            with open(fpath, "rb") as fh:
                data = fh.read()
                if b"6645" in data:
                    print(f"Found '6645' in {fpath} ({len(data)} bytes)")
                if b"5569" in data and f != "sample_output.csv":
                    print(f"Found '5569' in {fpath} ({len(data)} bytes)")
        except Exception as e:
            pass
