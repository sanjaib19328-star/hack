import pandas as pd
df = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/system_activity.csv')
for i in range(3845, 3865):
    r = df.iloc[i]
    print(f"{r['activity_id']} | {r['event_time']} | {r['event_type']} | {r['target_system']} | {r['resource_id']} | {r['details']}")
