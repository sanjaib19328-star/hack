import pandas as pd
import json

sample_reqs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_deletion_requests.csv')
sample_outs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_output.csv')
users = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/user_identities.csv')
sys_act = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/system_activity.csv')

for cid in ['case_01', 'case_02', 'case_03', 'case_04', 'case_18', 'case_20', 'case_26']:
    req = sample_reqs[sample_reqs['case_id'] == cid].iloc[0]
    out = sample_outs[sample_outs['case_id'] == cid].iloc[0]
    steps = json.loads(out['steps_json'])
    res_list = [s['resource_id'] for s in steps]
    
    t_start = req['requested_at']
    t_end = req['reported_at']
    
    # filter sys_act in this window
    acts = sys_act[(sys_act['event_time'] >= t_start) & (sys_act['event_time'] <= t_end)]
    act_res = acts['resource_id'].tolist()
    
    print(f"\n{cid} ({req['email']}) | {t_start} -> {t_end}")
    print(f"  Expected resources: {res_list}")
    print(f"  Activities in window ({len(acts)}):")
    for _, a in acts.iterrows():
        if a['resource_id'] in res_list or any(r in str(a['details']) for r in res_list):
            print(f"    * MATCH: {a['activity_id']} | {a['event_time']} | {a['event_type']} | {a['resource_id']} | {a['details']}")
