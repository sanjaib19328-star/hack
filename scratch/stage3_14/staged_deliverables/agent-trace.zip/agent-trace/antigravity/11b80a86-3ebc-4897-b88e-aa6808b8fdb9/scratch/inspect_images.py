import os
from PIL import Image

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")
img_dir = os.path.join(DATASET_DIR, "evidence", "images")

for fname in os.listdir(img_dir):
    fpath = os.path.join(img_dir, fname)
    im = Image.open(fpath)
    print(f"\n{fname}: size={im.size}, mode={im.mode}, info={im.info}")
