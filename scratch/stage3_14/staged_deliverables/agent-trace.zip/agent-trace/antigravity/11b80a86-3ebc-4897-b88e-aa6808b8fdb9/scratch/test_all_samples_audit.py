import os
import json
import csv
import re
import sqlite3
import pandas as pd
from collections import defaultdict

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

# Load users and audit log
users_df = pd.read_csv(os.path.join(DATASET_DIR, "user_identities.csv"))
audit_df = pd.read_csv(os.path.join(DATASET_DIR, "user_audit_log.csv"))
ef_df = pd.read_csv(os.path.join(DATASET_DIR, "evidence_files.csv"))
sys_act_df = pd.read_csv(os.path.join(DATASET_DIR, "system_activity.csv"))
rules_df = pd.read_csv(os.path.join(DATASET_DIR, "deletion_rules.csv"))
sample_outs_df = pd.read_csv(os.path.join(DATASET_DIR, "sample_output.csv"))
sample_reqs_df = pd.read_csv(os.path.join(DATASET_DIR, "sample_deletion_requests.csv"))

email_to_uid = {}
uid_to_identities = defaultdict(dict)

for idx, r in users_df.iterrows():
    u = r['user_id']
    e = str(r['email']).lower()
    email_to_uid[e] = u
    uid_to_identities[u]['user_id'] = u
    uid_to_identities[u]['email'] = e
    uid_to_identities[u]['emails'] = {e}
    uid_to_identities[u]['name'] = str(r['name']).lower() if pd.notna(r['name']) else ""
    uid_to_identities[u]['names'] = {str(r['name']).lower()} if pd.notna(r['name']) else set()
    uid_to_identities[u]['phones'] = {str(r['phone'])} if pd.notna(r['phone']) else set()
    uid_to_identities[u]['email_hash'] = str(r['email_hash']) if pd.notna(r['email_hash']) else ""

for idx, r in audit_df.iterrows():
    u = r['user_id']
    if u not in uid_to_identities:
        uid_to_identities[u]['user_id'] = u
        uid_to_identities[u]['emails'] = set()
        uid_to_identities[u]['names'] = set()
        uid_to_identities[u]['phones'] = set()
    
    if r['field_name'] == 'email':
        if pd.notna(r['old_value']):
            v = str(r['old_value']).lower().strip()
            email_to_uid[v] = u
            uid_to_identities[u]['emails'].add(v)
        if pd.notna(r['new_value']):
            v = str(r['new_value']).lower().strip()
            email_to_uid[v] = u
            uid_to_identities[u]['emails'].add(v)
    elif r['field_name'] == 'phone':
        if pd.notna(r['old_value']): uid_to_identities[u]['phones'].add(str(r['old_value']).strip())
        if pd.notna(r['new_value']): uid_to_identities[u]['phones'].add(str(r['new_value']).strip())
    elif r['field_name'] == 'name':
        if pd.notna(r['old_value']): uid_to_identities[u]['names'].add(str(r['old_value']).lower().strip())
        if pd.notna(r['new_value']): uid_to_identities[u]['names'].add(str(r['new_value']).lower().strip())

print(f"Loaded {len(uid_to_identities)} users and identities.")
