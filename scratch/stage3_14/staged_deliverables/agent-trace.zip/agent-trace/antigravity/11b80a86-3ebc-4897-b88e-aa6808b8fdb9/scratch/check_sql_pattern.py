"""
Check account to user pattern in SQL and evidence.
"""

import os
import glob
import re

dataset_dir = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main\dataset"

pairs = []
for fpath in glob.glob(os.path.join(dataset_dir, "**", "*.sql"), recursive=True):
    with open(fpath, encoding="utf-8", errors="ignore") as f:
        for line in f:
            if "customer_profiles" in line and "VALUES" in line:
                tokens = re.findall(r"'([^']*)'", line)
                if len(tokens) >= 2:
                    acc = tokens[0]
                    u = tokens[1]
                    pairs.append((acc, u, os.path.basename(fpath)))

print(f"Total account-user pairs found in SQL: {len(pairs)}")
for acc, u, fn in pairs[:20]:
    print(f"  {acc} <-> {u} in {fn}")
