with open(r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main\dataset\system_activity.csv", "r", encoding="utf-8") as f:
    for idx, line in enumerate(f):
        if "6645" in line:
            print(f"Line {idx+1}: {line.strip()}")
