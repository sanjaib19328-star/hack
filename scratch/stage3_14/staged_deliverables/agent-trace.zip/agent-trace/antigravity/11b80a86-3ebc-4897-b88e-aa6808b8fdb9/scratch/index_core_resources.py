"""
Index core resources including central observability export log files.
"""

import os
import glob
import re
import json
import csv
from collections import defaultdict

repo_dir = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
dataset_dir = os.path.join(repo_dir, "dataset")

# 1. Identity maps
email_to_uid = {}
uid_to_emails = defaultdict(set)
with open(os.path.join(dataset_dir, "user_identities.csv"), encoding="utf-8") as f:
    for r in csv.DictReader(f):
        u = r["user_id"]
        e = r["email"].lower().strip()
        email_to_uid[e] = u
        uid_to_emails[u].add(e)

with open(os.path.join(dataset_dir, "user_audit_log.csv"), encoding="utf-8") as f:
    for r in csv.DictReader(f):
        u = r["user_id"]
        if r.get("field_name") == "email":
            if r.get("old_value"):
                e = r["old_value"].lower().strip()
                email_to_uid[e] = u
                uid_to_emails[u].add(e)
            if r.get("new_value"):
                e = r["new_value"].lower().strip()
                email_to_uid[e] = u
                uid_to_emails[u].add(e)

user_account_map = {}
user_audit_map = {}

# A. From system_activity.csv
with open(os.path.join(dataset_dir, "system_activity.csv"), encoding="utf-8") as f:
    for r in csv.DictReader(f):
        res = r["resource_id"]
        details = r["details"]
        target = r["target_system"]
        m_u = re.search(r"user_\d+", details)
        m_e = re.search(r"[\w\.-]+@[\w\.-]+", details)
        uid = m_u.group(0) if m_u else (email_to_uid.get(m_e.group(0).lower()) if m_e else None)
        if uid:
            if target == "account_service" and res.startswith("account_"):
                user_account_map[uid] = res
            if target == "security_service" and res.startswith("audit_record_"):
                user_audit_map[uid] = res

# B. From ALL JSON files
for fpath in glob.glob(os.path.join(dataset_dir, "**", "*.json"), recursive=True):
    try:
        with open(fpath, encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        continue
    if "snapshots" in data:
        for snap in data["snapshots"]:
            ds = snap.get("data_store")
            for rec in snap.get("records", []):
                res = rec.get("resource_id")
                u = rec.get("customer_reference") or rec.get("user_id") or rec.get("subject_reference")
                e = (rec.get("email") or "").lower().strip()
                uid = u if (u and str(u).startswith("user_")) else email_to_uid.get(e)
                if uid and res:
                    if ds == "account_service" and res.startswith("account_"):
                        user_account_map[uid] = res
                    if ds == "security_service" and res.startswith("audit_record_"):
                        user_audit_map[uid] = res
    if "service_exports" in data:
        sec = data["service_exports"].get("security_service", {})
        for rec in sec.get("audit_records", []):
            res = rec.get("resource_id")
            sub = rec.get("subject_reference")
            if sub and str(sub).startswith("user_") and res:
                user_audit_map[str(sub)] = res
        acc = data["service_exports"].get("account_service", {})
        for rec in acc.get("profile_lookups", []):
            res = rec.get("resource_id")
            prof = rec.get("profile") or {}
            u = prof.get("customer_reference")
            e = (prof.get("email") or "").lower().strip()
            uid = u if (u and str(u).startswith("user_")) else email_to_uid.get(e)
            if uid and res:
                user_account_map[uid] = res

# C. From ALL Log files
for fpath in glob.glob(os.path.join(dataset_dir, "**", "*.log"), recursive=True):
    with open(fpath, encoding="utf-8", errors="ignore") as f:
        for line in f:
            # security_service audit_records
            if "security_service" in line or "audit_record_" in line:
                m_rec = re.search(r"resource_id=(audit_record_\d+)", line)
                m_sub = re.search(r"(?:subject_reference|correlation_key|lookup_key)=\"?([^\s\",]+)\"?", line)
                if m_rec and m_sub:
                    s = m_sub.group(1).lower()
                    uid = s if s.startswith("user_") else email_to_uid.get(s)
                    if uid:
                        user_audit_map[uid] = m_rec.group(1)
            # account_service profiles
            if "account_service" in line or "account_" in line:
                m_rec = re.search(r"resource_id=(account_\d+)", line)
                m_sub = re.search(r"(?:lookup_key|correlation_key|user_id|subject_ref)=\"?([^\s\",]+)\"?", line)
                if m_rec and m_sub:
                    s = m_sub.group(1).lower()
                    uid = s if s.startswith("user_") else email_to_uid.get(s)
                    if uid:
                        user_account_map[uid] = m_rec.group(1)

# D. From Handover text
handover_path = os.path.join(dataset_dir, "evidence", "records", "customer_account_handover_20261001.txt")
if os.path.exists(handover_path):
    with open(handover_path, encoding="utf-8") as f:
        for line in f:
            parts = [p.strip() for p in line.split("|")]
            if len(parts) >= 6:
                sys_id = parts[1]
                res_id = parts[2]
                subj = parts[5].lower()
                uid = subj if subj.startswith("user_") else email_to_uid.get(subj)
                if uid:
                    if sys_id == "account_service" and res_id.startswith("account_"):
                        user_account_map[uid] = res_id
                    if sys_id == "security_service" and res_id.startswith("audit_record_"):
                        user_audit_map[uid] = res_id

# E. From SQL dumps
for fpath in glob.glob(os.path.join(dataset_dir, "**", "*.sql"), recursive=True):
    with open(fpath, encoding="utf-8", errors="ignore") as f:
        for line in f:
            if "customer_profiles" in line:
                tokens = re.findall(r"'([^']*)'", line)
                if len(tokens) >= 4:
                    res = tokens[0]
                    u = tokens[1]
                    e = tokens[3].lower()
                    uid = u if (u and u.startswith("user_")) else email_to_uid.get(e)
                    if uid and res.startswith("account_"):
                        user_account_map[uid] = res

# Convention fallback for user_01 - user_10
for i in range(1, 11):
    u = f"user_{i:02d}"
    if u not in user_account_map:
        user_account_map[u] = f"account_{i:03d}"

print(f"Total resolved account_service mappings: {len(user_account_map)} / {len(uid_to_emails)}")
print(f"Total resolved security_service audit mappings: {len(user_audit_map)} / {len(uid_to_emails)}")

# Test on sample cases
with open(os.path.join(dataset_dir, "sample_output.csv"), encoding="utf-8") as f:
    sample_truth = {r["case_id"]: json.loads(r["steps_json"]) for r in csv.DictReader(f)}
with open(os.path.join(dataset_dir, "sample_deletion_requests.csv"), encoding="utf-8") as f:
    sample_reqs = {r["case_id"]: r for r in csv.DictReader(f)}

acc_matches = 0
acc_total = 0
audit_matches = 0
audit_total = 0

for cid, steps in sample_truth.items():
    req = sample_reqs[cid]
    u = email_to_uid.get(req["email"].lower().strip())
    for s in steps:
        if s["system_id"] == "account_service":
            acc_total += 1
            if u and user_account_map.get(u) == s["resource_id"]:
                acc_matches += 1
            else:
                print(f"Mismatch {cid} account: expected {s['resource_id']}, got {user_account_map.get(u)}")
        if s["system_id"] == "security_service":
            audit_total += 1
            if u and user_audit_map.get(u) == s["resource_id"]:
                audit_matches += 1
            else:
                print(f"Mismatch {cid} audit: expected {s['resource_id']}, got {user_audit_map.get(u)}")

print(f"\nSample Account Match: {acc_matches} / {acc_total}")
print(f"Sample Security Audit Match: {audit_matches} / {audit_total}")
