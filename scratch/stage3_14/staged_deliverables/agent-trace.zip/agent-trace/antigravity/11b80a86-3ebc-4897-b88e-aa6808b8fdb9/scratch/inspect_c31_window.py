import pandas as pd

sys_act = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/system_activity.csv')
sample_reqs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_deletion_requests.csv')

# Look at activities between 2026-09-04T12:00:00Z and 2026-09-06T12:00:00Z
sub = sys_act[(sys_act['event_time'] >= '2026-09-04T12:00:00Z') & (sys_act['event_time'] <= '2026-09-06T12:00:00Z')]
print(f"Total activities in case_31 window: {len(sub)}")
print(sub[sub['event_type'] == 'DELETE_RECORD'][['activity_id', 'event_time', 'resource_id', 'details']])
