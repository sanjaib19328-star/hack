import csv
import json
import os
from collections import defaultdict

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

with open(os.path.join(DATASET_DIR, "sample_output.csv"), "r", encoding="utf-8") as f:
    sample_outs = {r["case_id"]: json.loads(r["steps_json"]) for r in csv.DictReader(f)}

with open(os.path.join(DATASET_DIR, "sample_deletion_requests.csv"), "r", encoding="utf-8") as f:
    sample_reqs = {r["case_id"]: r for r in csv.DictReader(f)}

with open(os.path.join(DATASET_DIR, "user_identities.csv"), "r", encoding="utf-8") as f:
    user_identities = list(csv.DictReader(f))

with open(os.path.join(DATASET_DIR, "user_audit_log.csv"), "r", encoding="utf-8") as f:
    user_audit = list(csv.DictReader(f))

with open(os.path.join(DATASET_DIR, "system_activity.csv"), "r", encoding="utf-8") as f:
    system_activity = list(csv.DictReader(f))

email_to_uid = {}
for u in user_identities:
    email_to_uid[u["email"].lower()] = u["user_id"]
for a in user_audit:
    if a["field_name"] == "email":
        email_to_uid[a["old_value"].lower()] = a["user_id"]

for cid in sorted(sample_reqs.keys(), key=lambda x: int(x.split("_")[1])):
    req = sample_reqs[cid]
    uid = email_to_uid.get(req["email"].lower())
    req_at = req["requested_at"]
    audit_at = req["audit_at"]
    rep_at = req["reported_at"]
    steps = sample_outs[cid]
    step_res = set(s["resource_id"] for s in steps)

    # find activities in the window [req_at - 1h, rep_at + 2h]
    window_acts = []
    for a in system_activity:
        if req_at[:10] <= a["event_time"][:10] <= rep_at[:10]:
            # check if resource or details or time matches
            window_acts.append(a)

    # Check which activities actually involve step_res
    involved_acts = [a for a in system_activity if a["resource_id"] in step_res]
    print(f"\nCase {cid} ({uid}, email={req['email']}, req={req_at}, rep={rep_at}, audit={audit_at}):")
    print(f"  Step resources ({len(step_res)}): {sorted(step_res)}")
    for a in involved_acts:
        print(f"    Act {a['activity_id']} @ {a['event_time']}: {a['event_type']} {a['source_system']}->{a['target_system']} {a['resource_id']} ({a['reported_result']}) {a['details']}")
