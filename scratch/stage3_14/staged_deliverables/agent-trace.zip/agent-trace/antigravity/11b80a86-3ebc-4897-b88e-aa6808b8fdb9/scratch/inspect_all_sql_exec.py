import os
import glob
import sqlite3

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")
sql_files = glob.glob(os.path.join(DATASET_DIR, "evidence", "databases", "*.sql"))

print(f"Inspecting {len(sql_files)} SQL files...")

all_tables = set()
for sf in sql_files:
    # create in-memory sqlite db and execute sql
    con = sqlite3.connect(":memory:")
    cur = con.cursor()
    with open(sf, "r", encoding="utf-8", errors="ignore") as f:
        sql_text = f.read()
    try:
        cur.executescript(sql_text)
        tables = [r[0] for r in cur.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
        for t in tables:
            cols = [c[1] for c in cur.execute(f"PRAGMA table_info('{t}')").fetchall()]
            all_tables.add((t, tuple(cols)))
    except Exception as e:
        print(f"Error executing {os.path.basename(sf)}: {e}")
    finally:
        con.close()

print(f"\nDiscovered {len(all_tables)} distinct table schemas across all SQL files:")
for t, cols in sorted(all_tables):
    print(f"  Table '{t}': {cols}")
