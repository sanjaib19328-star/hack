import csv
import json

with open('hackerrank-orchestrate-october26-main/output.csv', 'r', encoding='utf-8') as f:
    rows = list(csv.DictReader(f))

empty_steps = [r for r in rows if len(json.loads(r['steps_json'])) == 0]
print(f"Total cases with empty steps: {len(empty_steps)}")
for r in empty_steps[:25]:
    print(r['case_id'], r['deletion_status'])
