import csv
import json
import os
from collections import Counter

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

with open(os.path.join(DATASET_DIR, "evidence_files.csv"), "r", encoding="utf-8") as f:
    ev_files = list(csv.DictReader(f))

print(f"Total evidence files: {len(ev_files)}")

# Check file types
ext_counter = Counter(os.path.splitext(e["file_path"])[1] for e in ev_files)
print("File extensions:", ext_counter)

# Check existence and sizes
missing = []
for e in ev_files:
    full_path = os.path.join(DATASET_DIR, e["file_path"])
    if not os.path.exists(full_path):
        missing.append(e)

print(f"Missing evidence files: {len(missing)}")
if missing:
    for m in missing[:5]:
        print("Missing:", m)

# Let's inspect each extension
for ext in sorted(ext_counter.keys()):
    matches = [e for e in ev_files if e["file_path"].endswith(ext)]
    print(f"\nExtension {ext} ({len(matches)} files):")
    for m in matches[:3]:
        full_path = os.path.join(DATASET_DIR, m["file_path"])
        sz = os.path.getsize(full_path) if os.path.exists(full_path) else 0
        print(f"  {m['file_id']}: {m['file_path']} ({sz} bytes, captured_at={m['captured_at']}, origin={m['origin']})")
