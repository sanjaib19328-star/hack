import csv
import json
import os
from collections import defaultdict

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

with open(os.path.join(DATASET_DIR, "sample_output.csv"), "r", encoding="utf-8") as f:
    sample_outs = {r["case_id"]: json.loads(r["steps_json"]) for r in csv.DictReader(f)}

with open(os.path.join(DATASET_DIR, "sample_deletion_requests.csv"), "r", encoding="utf-8") as f:
    sample_reqs = {r["case_id"]: r for r in csv.DictReader(f)}

with open(os.path.join(DATASET_DIR, "user_identities.csv"), "r", encoding="utf-8") as f:
    user_identities = list(csv.DictReader(f))

with open(os.path.join(DATASET_DIR, "user_audit_log.csv"), "r", encoding="utf-8") as f:
    user_audit = list(csv.DictReader(f))

with open(os.path.join(DATASET_DIR, "system_activity.csv"), "r", encoding="utf-8") as f:
    system_activity = list(csv.DictReader(f))

with open(os.path.join(DATASET_DIR, "evidence_files.csv"), "r", encoding="utf-8") as f:
    evidence_manifest = {r["file_id"]: r for r in csv.DictReader(f)}

# Map email -> user_id
email_to_uid = {}
uid_to_user = {}
for u in user_identities:
    email_to_uid[u["email"].lower()] = u["user_id"]
    uid_to_user[u["user_id"]] = u

for a in user_audit:
    if a["field_name"] == "email":
        email_to_uid[a["old_value"].lower()] = a["user_id"]

# For each sample case, inspect how each step was determined
for cid in sorted(sample_outs.keys(), key=lambda x: int(x.split("_")[1])):
    req = sample_reqs[cid]
    uid = email_to_uid.get(req["email"].lower())
    steps = sample_outs[cid]
    print(f"\n==================== Case {cid} (uid={uid}, email={req['email']}) ====================")
    for s in steps:
        ev = s.get("evidence_id")
        ev_file = evidence_manifest.get(ev, {}).get("file_path", "")
        print(f"  Step {s['step_no']}: phase={s['phase']} sys={s['system_id']} res={s['resource_id']} op={s['operation']} st={s['state']} ev={ev} ({ev_file})")
