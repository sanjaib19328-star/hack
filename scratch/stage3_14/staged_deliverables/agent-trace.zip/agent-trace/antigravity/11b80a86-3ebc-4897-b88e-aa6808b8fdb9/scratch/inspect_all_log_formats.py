import os

log_dir = 'hackerrank-orchestrate-october26-main/dataset/evidence/logs'
for f in sorted(os.listdir(log_dir)):
    p = os.path.join(log_dir, f)
    with open(p, 'r', encoding='utf-8', errors='ignore') as fh:
        lines = [fh.readline().strip() for _ in range(3)]
        print(f"=== {f} ===")
        for l in lines:
            print("  ", l[:120])
