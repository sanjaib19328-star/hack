import os
import json
import pandas as pd

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

ef = pd.read_csv(os.path.join(DATASET_DIR, "evidence_files.csv"))
bundles = ef[ef['origin'] == 'records_assurance_snapshot_bundle']

print(f"Total bundles: {len(bundles)}")
for idx, r in bundles.iterrows():
    fpath = os.path.join(DATASET_DIR, r['file_path'])
    with open(fpath, 'r', encoding='utf-8') as f:
        d = json.load(f)
    print(f"{r['file_id']} ({r['captured_at']}): snapshots={len(d.get('snapshots', []))}")
    for s in d.get('snapshots', []):
        print(f"   store={s.get('data_store')}, col={s.get('collection')}, records={len(s.get('records', []))}")
