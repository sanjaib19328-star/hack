import pandas as pd
import json
from collections import defaultdict

sys_act = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/system_activity.csv')
sample_outs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_output.csv')

# Let's inspect all resources across sample_output.csv and how they appear in system_activity
all_sample_res = set()
for idx, r in sample_outs.iterrows():
    steps = json.loads(r['steps_json'])
    for s in steps:
        all_sample_res.add(s['resource_id'])

print(f"Total unique sample resources: {len(all_sample_res)}")

res_to_act = defaultdict(list)
for idx, r in sys_act.iterrows():
    rid = r['resource_id']
    if rid in all_sample_res:
        res_to_act[rid].append(r.to_dict())

print(f"Sample resources present in system_activity: {len(res_to_act)} / {len(all_sample_res)}")

missing = all_sample_res - set(res_to_act.keys())
print("Missing resources from system_activity:", missing)
