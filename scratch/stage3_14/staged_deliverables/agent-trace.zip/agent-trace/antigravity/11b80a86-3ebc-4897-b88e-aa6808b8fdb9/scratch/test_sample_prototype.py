import os
import json
import csv
import re
import sqlite3
import pandas as pd
from collections import defaultdict

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

# Load users and audit logs
users_df = pd.read_csv(os.path.join(DATASET_DIR, "user_identities.csv"))
audit_df = pd.read_csv(os.path.join(DATASET_DIR, "user_audit_log.csv"))
ef_df = pd.read_csv(os.path.join(DATASET_DIR, "evidence_files.csv"))
sys_act_df = pd.read_csv(os.path.join(DATASET_DIR, "system_activity.csv"))
sample_outs_df = pd.read_csv(os.path.join(DATASET_DIR, "sample_output.csv"))
sample_reqs_df = pd.read_csv(os.path.join(DATASET_DIR, "sample_deletion_requests.csv"))

print("Loaded all CSV metadata successfully.")
