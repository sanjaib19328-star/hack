import csv
import json
import os
from collections import defaultdict

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

with open(os.path.join(DATASET_DIR, "sample_output.csv"), "r", encoding="utf-8") as f:
    sample_outs = {r["case_id"]: json.loads(r["steps_json"]) for r in csv.DictReader(f)}

all_sample_resources = set()
for steps in sample_outs.values():
    for s in steps:
        all_sample_resources.add(s["resource_id"])

print(f"Total unique resources across 32 sample cases: {len(all_sample_resources)}")

# Let's search each resource across all files in dataset/
res_locations = defaultdict(list)
for root, dirs, files in os.walk(DATASET_DIR):
    for f in files:
        if f == "sample_output.csv":
            continue
        fpath = os.path.join(root, f)
        relpath = os.path.relpath(fpath, DATASET_DIR)
        try:
            with open(fpath, "r", encoding="utf-8", errors="ignore") as fh:
                content = fh.read()
                for res in all_sample_resources:
                    if res in content:
                        res_locations[res].append(relpath)
        except Exception:
            pass

found_cnt = 0
missing_cnt = 0
for res in sorted(all_sample_resources):
    locs = res_locations.get(res, [])
    if locs:
        found_cnt += 1
        print(f"FOUND {res:20s}: in {len(locs)} files -> {locs[:3]}")
    else:
        missing_cnt += 1
        print(f"MISSING {res:20s}")

print(f"\nSummary: {found_cnt} found, {missing_cnt} missing out of {len(all_sample_resources)}")
