import pandas as pd

sys_act = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/system_activity.csv')

# Find all activities where "submitted primary profile account_" in details
primary_acc_acts = sys_act[sys_act['details'].str.contains('primary profile account_', na=False)].copy()
print(f"Total primary profile account submissions: {len(primary_acc_acts)}")
print(primary_acc_acts.head(20)[['activity_id', 'event_time', 'resource_id', 'details']])
