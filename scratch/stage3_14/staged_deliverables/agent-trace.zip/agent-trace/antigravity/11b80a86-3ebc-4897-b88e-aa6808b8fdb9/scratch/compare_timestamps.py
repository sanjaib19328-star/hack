import csv
import json
import os

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

# Load sample requests
with open(os.path.join(DATASET_DIR, "sample_deletion_requests.csv"), "r", encoding="utf-8") as f:
    sample_reqs = {r["case_id"]: r for r in csv.DictReader(f)}

# Load sample outputs
with open(os.path.join(DATASET_DIR, "sample_output.csv"), "r", encoding="utf-8") as f:
    sample_outs = {r["case_id"]: (r["deletion_status"], json.loads(r["steps_json"])) for r in csv.DictReader(f)}

# Load evidence manifest
with open(os.path.join(DATASET_DIR, "evidence_files.csv"), "r", encoding="utf-8") as f:
    evidence_manifest = {r["file_id"]: r for r in csv.DictReader(f)}

print("Case ID | audit_at | Cited Evidence | Evidence captured_at | Difference (audit_at - captured_at)")
for cid in sorted(sample_reqs.keys(), key=lambda x: int(x.split("_")[1])):
    req = sample_reqs[cid]
    status, steps = sample_outs[cid]
    cited_evs = set(s["evidence_id"] for s in steps if s.get("evidence_id"))
    for ev in cited_evs:
        ev_info = evidence_manifest.get(ev, {})
        cap = ev_info.get("captured_at", "")
        print(f"{cid:7s} | {req['audit_at']} | {ev:11s} | {cap} | {req['audit_at']} vs {cap}")
