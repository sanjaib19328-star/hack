import csv
import json
import os
from collections import Counter

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

with open(os.path.join(DATASET_DIR, "sample_output.csv"), "r", encoding="utf-8") as f:
    sample_out = list(csv.DictReader(f))

print(f"Sample outputs count: {len(sample_out)}")
status_counts = Counter(r["deletion_status"] for r in sample_out)
print(f"Status counts: {status_counts}")

ev_counter = Counter()
op_counter = Counter()
sys_counter = Counter()

for r in sample_out:
    steps = json.loads(r["steps_json"])
    for s in steps:
        if s.get("evidence_id"):
            ev_counter[s["evidence_id"]] += 1
        op_counter[s["operation"]] += 1
        sys_counter[s["system_id"]] += 1

print("\nTop evidence IDs in sample_output:")
for ev, cnt in ev_counter.most_common():
    print(f"  {ev}: {cnt}")

print("\nOperations in sample_output:")
for op, cnt in op_counter.most_common():
    print(f"  {op}: {cnt}")

print("\nSystems in sample_output:")
for sys, cnt in sys_counter.most_common():
    print(f"  {sys}: {cnt}")
