import os
import json
import csv
import pandas as pd
from collections import defaultdict

sample_reqs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_deletion_requests.csv')
sample_outs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_output.csv')
users = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/user_identities.csv')
audit_log = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/user_audit_log.csv')
ef = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/evidence_files.csv')

email_to_uid = {}
uid_to_identifiers = defaultdict(set)

for idx, r in users.iterrows():
    u = r['user_id']
    e = str(r['email']).lower()
    email_to_uid[e] = u
    uid_to_identifiers[u].add(u)
    uid_to_identifiers[u].add(e)
    if pd.notna(r['phone']): uid_to_identifiers[u].add(str(r['phone']))

for idx, r in audit_log.iterrows():
    u = r['user_id']
    uid_to_identifiers[u].add(u)
    if pd.notna(r['old_value']):
        val = str(r['old_value']).strip()
        uid_to_identifiers[u].add(val.lower() if '@' in val else val)
        if '@' in val: email_to_uid[val.lower()] = u
    if pd.notna(r['new_value']):
        val = str(r['new_value']).strip()
        uid_to_identifiers[u].add(val.lower() if '@' in val else val)
        if '@' in val: email_to_uid[val.lower()] = u

merged = pd.merge(sample_reqs, sample_outs, on='case_id')

# Preload content or index of evidence files
print("Indexing evidence files...")
ev_file_contents = {}
for idx, r in ef.iterrows():
    fpath = os.path.join('hackerrank-orchestrate-october26-main/dataset', r['file_path'])
    try:
        with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
            ev_file_contents[r['file_id']] = (r['captured_at'], f.read())
    except Exception as ex:
        pass

print(f"Loaded {len(ev_file_contents)} text evidence files.")

for idx, r in merged.iterrows():
    cid = r['case_id']
    uid = email_to_uid[r['email'].lower()]
    audit_at = r['audit_at']
    identifiers = uid_to_identifiers[uid]
    steps = json.loads(r['steps_json'])
    expected_evs = set(s['evidence_id'] for s in steps if s['evidence_id'])
    
    # Which evidence files contain any identifier AND captured_at <= audit_at?
    matching_evs = []
    for fid, (cap_at, text) in ev_file_contents.items():
        if cap_at <= audit_at:
            # check if any identifier in text
            if any(ident in text for ident in identifiers):
                matching_evs.append(fid)
                
    print(f"{cid} ({uid}) | audit_at={audit_at}")
    print(f"  Expected evs: {expected_evs}")
    print(f"  Matched evs:  {matching_evs}")
