import json

with open(r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main\dataset\evidence\records\customer_data_snapshot_bundle_20260917.json", "r", encoding="utf-8") as f:
    data = json.load(f)

for k, v in data.items():
    s = str(v)
    if "account_3866" in s or "user_27" in s or "ananya" in s:
        print(f"Key in bundle: {k}")
        if isinstance(v, list):
            for item in v:
                if "account_3866" in str(item) or "user_27" in str(item) or "ananya" in str(item):
                    print(f"  Item: {item}")
        elif isinstance(v, dict):
            for subk, subv in v.items():
                if "account_3866" in str(subv) or "user_27" in str(subv) or "ananya" in str(subv):
                    print(f"  Subkey {subk}: {subv}")
