import pandas as pd
import json

sample_outs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_output.csv')
sample_reqs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_deletion_requests.csv')
sys_act = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/system_activity.csv')

# Check case 26, 27, 28, 29, 30
for cid in ['case_26', 'case_27', 'case_28', 'case_29', 'case_30']:
    srow = sample_outs[sample_outs['case_id'] == cid].iloc[0]
    rrow = sample_reqs[sample_reqs['case_id'] == cid].iloc[0]
    steps = json.loads(srow['steps_json'])
    res_list = [s['resource_id'] for s in steps if not s['resource_id'].startswith('audit_record')]
    
    print(f"\n{cid} ({rrow['email']}): requested={rrow['requested_at']} -> reported={rrow['reported_at']}")
    print(f"  Operational resources: {res_list}")
    for res in res_list:
        sub = sys_act[sys_act['resource_id'] == res]
        for _, a in sub.iterrows():
            print(f"    {a['activity_id']} | {a['event_time']} | {a['event_type']:20s} | {a['resource_id']:15s} | {a['details']}")
