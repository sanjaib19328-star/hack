import os
import json
import csv
import pandas as pd
from collections import defaultdict

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

# Load sample output for case_21 to case_30
sample_outs = pd.read_csv(os.path.join(DATASET_DIR, "sample_output.csv"))
sample_reqs = pd.read_csv(os.path.join(DATASET_DIR, "sample_deletion_requests.csv"))
users = pd.read_csv(os.path.join(DATASET_DIR, "user_identities.csv"))
audit_log = pd.read_csv(os.path.join(DATASET_DIR, "user_audit_log.csv"))

email_to_uid = {}
uid_to_identities = defaultdict(dict)
for idx, r in users.iterrows():
    u = r['user_id']
    e = str(r['email']).lower()
    email_to_uid[e] = u
    uid_to_identities[u] = {'user_id': u, 'emails': {e}}

for idx, r in audit_log.iterrows():
    u = r['user_id']
    if r['field_name'] == 'email':
        if pd.notna(r['old_value']):
            email_to_uid[str(r['old_value']).lower().strip()] = u
            uid_to_identities[u]['emails'].add(str(r['old_value']).lower().strip())
        if pd.notna(r['new_value']):
            email_to_uid[str(r['new_value']).lower().strip()] = u
            uid_to_identities[u]['emails'].add(str(r['new_value']).lower().strip())

# Order definitions
OP_ORDER = {
    'FINDING': {
        'REPORT_REMAINING_RECORD': 1,
        'REPORT_EXPOSED_PII': 2,
        'REPORT_ACTIVE_DATA_FLOW': 3,
        'REPORT_RESTORE_RISK': 4
    },
    'REMEDIATION': {
        'DISABLE_DATA_FLOW': 1,
        'BLOCK_RESTORE': 2,
        'DELETE_RECORD': 3,
        'REDACT_RECORD': 4,
        'ANONYMIZE_RECORD': 5
    },
    'VERIFICATION': {
        'VERIFY_RECORD_ABSENT': 1,
        'VERIFY_RECORD_PRESENT': 2,
        'VERIFY_RECORD_REDACTED': 3,
        'VERIFY_RECORD_ANONYMIZED': 4,
        'VERIFY_DATA_FLOW_DISABLED': 5,
        'VERIFY_RESTORE_BLOCKED': 6
    }
}
PHASE_ORDER = {'FINDING': 1, 'REMEDIATION': 2, 'VERIFICATION': 3}

def sort_steps(steps):
    return sorted(
        steps,
        key=lambda s: (
            PHASE_ORDER[s['phase']],
            OP_ORDER[s['phase']][s['operation']],
            s['system_id'],
            s['resource_id']
        )
    )

def audit_service_resource_export(file_path, file_id, user_id, user_emails):
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    exports = data.get('service_exports', {})
    
    findings = []
    remediations = []
    verifications = []
    
    # 1. account_service
    acc = exports.get('account_service', {})
    for item in acc.get('profile_lookups', []):
        prof = item.get('profile') or {}
        p_email = str(prof.get('email', '')).lower() if prof.get('email') else ""
        p_ref = str(prof.get('customer_reference', '')) if prof.get('customer_reference') else ""
        res_id = item.get('resource_id')
        status_code = item.get('status_code')
        
        # Check if matches user
        # Note: if status_code == 404, prof is None, but query or how do we match?
        # Let's see how profile_lookups match user
        matches = False
        if p_email and p_email in user_emails: matches = True
        if p_ref and p_ref == user_id: matches = True
        
        if matches:
            if status_code == 200:
                findings.append({'system_id': 'account_service', 'resource_id': res_id, 'operation': 'REPORT_REMAINING_RECORD', 'state': 'PRESENT', 'evidence_id': file_id, 'phase': 'FINDING'})
                remediations.append({'system_id': 'account_service', 'resource_id': res_id, 'operation': 'DELETE_RECORD', 'state': 'ABSENT', 'evidence_id': '', 'phase': 'REMEDIATION'})
                verifications.append({'system_id': 'account_service', 'resource_id': res_id, 'operation': 'VERIFY_RECORD_ABSENT', 'state': 'ABSENT', 'evidence_id': '', 'phase': 'VERIFICATION'})
            elif status_code == 404:
                verifications.append({'system_id': 'account_service', 'resource_id': res_id, 'operation': 'VERIFY_RECORD_ABSENT', 'state': 'ABSENT', 'evidence_id': file_id, 'phase': 'VERIFICATION'})

    # Let's inspect how lookups match when status_code == 404
    return findings, remediations, verifications

print("Testing service resource export parsing...")
