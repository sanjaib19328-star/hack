"""
Map sample cases to their cited evidence IDs and files.
"""

import os
import csv
import json
from collections import defaultdict

repo_dir = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
dataset_dir = os.path.join(repo_dir, "dataset")

with open(os.path.join(dataset_dir, "evidence_files.csv"), encoding="utf-8") as f:
    ev_files = {r["file_id"]: r for r in csv.DictReader(f)}

with open(os.path.join(dataset_dir, "sample_deletion_requests.csv"), encoding="utf-8") as f:
    reqs = {r["case_id"]: r for r in csv.DictReader(f)}

with open(os.path.join(dataset_dir, "sample_output.csv"), encoding="utf-8") as f:
    sample_out = {r["case_id"]: (r["deletion_status"], json.loads(r["steps_json"])) for r in csv.DictReader(f)}

ev_to_cases = defaultdict(list)
for cid, (st, steps) in sample_out.items():
    req = reqs[cid]
    audit_at = req["audit_at"]
    cited_evs = set(s["evidence_id"] for s in steps if s["evidence_id"])
    for ev_id in cited_evs:
        ev_info = ev_files.get(ev_id, {})
        ev_to_cases[ev_id].append((cid, st, audit_at, ev_info.get("captured_at"), ev_info.get("origin"), ev_info.get("file_path")))

print(f"Evidence files cited in sample_output.csv ({len(ev_to_cases)} unique evidence files):")
for ev_id, cases in sorted(ev_to_cases.items()):
    fn = cases[0][5]
    origin = cases[0][4]
    cap_at = cases[0][3]
    c_list = [c[0] for c in cases]
    print(f"\n{ev_id} | {origin} | cap_at: {cap_at} | path: {fn}")
    print(f"   Cited by {len(cases)} cases: {c_list}")
