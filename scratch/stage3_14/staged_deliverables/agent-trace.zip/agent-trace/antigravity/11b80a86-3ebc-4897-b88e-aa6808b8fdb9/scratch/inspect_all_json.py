import csv
import json
import os
import glob
import re

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

with open(os.path.join(DATASET_DIR, "evidence_files.csv"), "r", encoding="utf-8") as f:
    evidence_manifest = {r["file_id"]: r for r in csv.DictReader(f)}

print(f"Loaded evidence manifest: {len(evidence_manifest)} files.")

# Check all json files in evidence/records
json_files = glob.glob(os.path.join(DATASET_DIR, "evidence", "records", "*.json"))
print(f"Total json record files: {len(json_files)}")

# Let's inspect root keys of each json file
json_structures = {}
for jf in json_files:
    fname = os.path.basename(jf)
    with open(jf, "r", encoding="utf-8") as f:
        try:
            d = json.load(f)
            prefix = "_".join(fname.split("_")[:-1])
            if prefix not in json_structures:
                json_structures[prefix] = (list(d.keys()), fname)
        except Exception as e:
            print(f"Error {fname}: {e}")

for p, (keys, sample) in json_structures.items():
    print(f"JSON prefix {p} ({sample}): keys={keys}")
