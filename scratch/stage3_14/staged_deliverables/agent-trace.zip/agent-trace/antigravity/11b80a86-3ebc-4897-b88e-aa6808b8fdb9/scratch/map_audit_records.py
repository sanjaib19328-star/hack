import os
import json
import csv
import re
import pandas as pd
from collections import defaultdict

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

# Load users and audit log
users_df = pd.read_csv(os.path.join(DATASET_DIR, "user_identities.csv"))
audit_df = pd.read_csv(os.path.join(DATASET_DIR, "user_audit_log.csv"))
ef_df = pd.read_csv(os.path.join(DATASET_DIR, "evidence_files.csv"))
sys_act_df = pd.read_csv(os.path.join(DATASET_DIR, "system_activity.csv"))
sample_outs_df = pd.read_csv(os.path.join(DATASET_DIR, "sample_output.csv"))
sample_reqs_df = pd.read_csv(os.path.join(DATASET_DIR, "sample_deletion_requests.csv"))

email_to_uid = {}
uid_to_identities = defaultdict(dict)

for idx, r in users_df.iterrows():
    u = r['user_id']
    e = str(r['email']).lower()
    email_to_uid[e] = u
    uid_to_identities[u]['user_id'] = u
    uid_to_identities[u]['email'] = e
    uid_to_identities[u]['emails'] = {e}
    uid_to_identities[u]['name'] = str(r['name']).lower() if pd.notna(r['name']) else ""
    uid_to_identities[u]['names'] = {str(r['name']).lower()} if pd.notna(r['name']) else set()
    uid_to_identities[u]['phones'] = {str(r['phone'])} if pd.notna(r['phone']) else set()
    uid_to_identities[u]['email_hash'] = str(r['email_hash']) if pd.notna(r['email_hash']) else ""

for idx, r in audit_df.iterrows():
    u = r['user_id']
    if u not in uid_to_identities:
        uid_to_identities[u]['user_id'] = u
        uid_to_identities[u]['emails'] = set()
        uid_to_identities[u]['names'] = set()
        uid_to_identities[u]['phones'] = set()
    
    if r['field_name'] == 'email':
        if pd.notna(r['old_value']):
            v = str(r['old_value']).lower().strip()
            email_to_uid[v] = u
            uid_to_identities[u]['emails'].add(v)
        if pd.notna(r['new_value']):
            v = str(r['new_value']).lower().strip()
            email_to_uid[v] = u
            uid_to_identities[u]['emails'].add(v)
    elif r['field_name'] == 'phone':
        if pd.notna(r['old_value']): uid_to_identities[u]['phones'].add(str(r['old_value']).strip())
        if pd.notna(r['new_value']): uid_to_identities[u]['phones'].add(str(r['new_value']).strip())
    elif r['field_name'] == 'name':
        if pd.notna(r['old_value']): uid_to_identities[u]['names'].add(str(r['old_value']).lower().strip())
        if pd.notna(r['new_value']): uid_to_identities[u]['names'].add(str(r['new_value']).lower().strip())

# Map each user to audit_record from all evidence or security services
# Let's see: where do audit records live?
uid_to_audit_record = {}
# 1. in evidence files
for root, dirs, files in os.walk(os.path.join(DATASET_DIR, "evidence")):
    for f in files:
        fpath = os.path.join(root, f)
        try:
            with open(fpath, 'r', encoding='utf-8', errors='ignore') as fh:
                txt = fh.read()
                # Find all occurrences of audit_record_XXXX and user_XX
                for match in re.finditer(r'(audit_record_\d+)', txt):
                    rec = match.group(1)
                    # search around this position for user_XX
                    start = max(0, match.start() - 300)
                    end = min(len(txt), match.end() + 300)
                    window = txt[start:end]
                    for u_match in re.finditer(r'(user_\d+)', window):
                        u = u_match.group(1)
                        if u not in uid_to_audit_record:
                            uid_to_audit_record[u] = rec
        except Exception:
            pass

print(f"Mapped {len(uid_to_audit_record)} audit records to users.")
for u in ['user_21', 'user_24', 'user_25', 'user_26', 'user_27', 'user_28', 'user_29', 'user_30']:
    print(u, uid_to_audit_record.get(u))
