with open(r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main\dataset\evidence\logs\application_trace_eu_north_20260302.log", "r", encoding="utf-8") as f:
    for line in f:
        if "6645" in line:
            print(line.strip())
