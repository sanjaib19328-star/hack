import csv
import json
import os

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

with open(os.path.join(DATASET_DIR, "deletion_requests.csv"), "r", encoding="utf-8") as f:
    full_reqs = list(csv.DictReader(f))

del_terms = ["delet", "remov", "eras", "clos", "cancel", "terminat", "destroy", "wipe",
             "supprim", "effac", "clôtur", "fermer",
             "elimin", "borr", "cerr",
             "lösch", "entfern", "schließ",
             "削除", "消去", "解約",
             "apag", "exclu", "encerr",
             "chiud"]

with open("scratch/non_deletion_candidates.txt", "w", encoding="utf-8") as out_f:
    for r in full_reqs:
        text = r["request_text"].lower()
        has_del = any(term in text for term in del_terms)
        if not has_del:
            out_f.write(f"[{r['case_id']}] {r['request_text']}\n")
print("Done writing non_deletion_candidates.txt")
