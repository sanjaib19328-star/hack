import pandas as pd
import json

df = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_output.csv')
for idx, row in df.iterrows():
    steps = json.loads(row['steps_json'])
    evs = set(s['evidence_id'] for s in steps if s['evidence_id'])
    print(f"{row['case_id']}: {evs}")
