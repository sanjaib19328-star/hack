import pandas as pd
import json

df = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_output.csv')
c4 = df[df['case_id'] == 'case_04'].iloc[0]
print("case_04 status:", c4['deletion_status'])
for s in json.loads(c4['steps_json']):
    print(s)
