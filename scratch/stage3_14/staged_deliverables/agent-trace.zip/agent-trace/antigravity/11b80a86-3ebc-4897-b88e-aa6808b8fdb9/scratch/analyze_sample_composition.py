"""
Analyze step composition across sample cases in sample_output.csv.
"""

import os
import csv
import json
from collections import defaultdict, Counter

repo_dir = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
dataset_dir = os.path.join(repo_dir, "dataset")

with open(os.path.join(dataset_dir, "sample_output.csv"), encoding="utf-8") as f:
    sample_out = {r["case_id"]: (r["deletion_status"], json.loads(r["steps_json"])) for r in csv.DictReader(f)}

with open(os.path.join(dataset_dir, "sample_deletion_requests.csv"), encoding="utf-8") as f:
    sample_reqs = {r["case_id"]: r for r in csv.DictReader(f)}

with open(os.path.join(dataset_dir, "evidence_files.csv"), encoding="utf-8") as f:
    ev_files = {r["file_id"]: r for r in csv.DictReader(f)}

for cid in sorted(sample_out.keys()):
    st, steps = sample_out[cid]
    req = sample_reqs[cid]
    sys_list = [s["system_id"] for s in steps]
    op_list = [s["operation"] for s in steps]
    ev_list = list(set(s["evidence_id"] for s in steps if s["evidence_id"]))
    print(f"{cid} [{st}]: systems={sys_list}, evs={ev_list}")
