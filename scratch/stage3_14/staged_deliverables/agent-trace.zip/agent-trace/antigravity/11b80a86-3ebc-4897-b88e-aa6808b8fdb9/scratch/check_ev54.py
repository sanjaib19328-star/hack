with open(r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main\dataset\evidence\databases\customer_accounts_failover_replica_20260902.sql", "r", encoding="utf-8") as f:
    text = f.read()

print("evidence_54 length:", len(text))
for term in ["user_01", "user_02", "user_04", "account_001", "account_002", "account_004", "amina", "mateo", "thandiwe"]:
    print(f"'{term}' in evidence_54: {term in text.lower()}")
