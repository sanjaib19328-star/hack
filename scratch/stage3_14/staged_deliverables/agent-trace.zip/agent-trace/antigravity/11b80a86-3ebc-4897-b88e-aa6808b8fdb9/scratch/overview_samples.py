import csv
import json
import os
import glob
import sqlite3
import re
from collections import defaultdict

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

# 1. Load users and identities
with open(os.path.join(DATASET_DIR, "user_identities.csv"), "r", encoding="utf-8") as f:
    user_identities = list(csv.DictReader(f))
with open(os.path.join(DATASET_DIR, "user_audit_log.csv"), "r", encoding="utf-8") as f:
    user_audit = list(csv.DictReader(f))
with open(os.path.join(DATASET_DIR, "evidence_files.csv"), "r", encoding="utf-8") as f:
    evidence_manifest = {r["file_id"]: r for r in csv.DictReader(f)}

email_to_uid = {}
uid_to_emails = defaultdict(set)
uid_to_names = defaultdict(set)
uid_to_phones = defaultdict(set)

for u in user_identities:
    uid = u["user_id"]
    e = u["email"].lower()
    email_to_uid[e] = uid
    uid_to_emails[uid].add(e)
    if u.get("name"): uid_to_names[uid].add(u["name"].lower())
    if u.get("phone"): uid_to_phones[uid].add(u["phone"])

for a in user_audit:
    uid = a["user_id"]
    if a["field_name"] == "email":
        email_to_uid[a["old_value"].lower()] = uid
        uid_to_emails[uid].add(a["old_value"].lower())
        uid_to_emails[uid].add(a["new_value"].lower())
    elif a["field_name"] == "phone":
        uid_to_phones[uid].add(a["old_value"])
        uid_to_phones[uid].add(a["new_value"])
    elif a["field_name"] == "name":
        uid_to_names[uid].add(a["old_value"].lower())
        uid_to_names[uid].add(a["new_value"].lower())

print(f"Users loaded: {len(user_identities)}, email mappings: {len(email_to_uid)}")

# Let's inspect how sample cases match evidence files
with open(os.path.join(DATASET_DIR, "sample_output.csv"), "r", encoding="utf-8") as f:
    sample_outs = {r["case_id"]: (r["deletion_status"], json.loads(r["steps_json"])) for r in csv.DictReader(f)}

with open(os.path.join(DATASET_DIR, "sample_deletion_requests.csv"), "r", encoding="utf-8") as f:
    sample_reqs = {r["case_id"]: r for r in csv.DictReader(f)}

for cid in sorted(sample_reqs.keys(), key=lambda x: int(x.split("_")[1])):
    req = sample_reqs[cid]
    status, steps = sample_outs[cid]
    uid = email_to_uid.get(req["email"].lower())
    audit_at = req["audit_at"]
    # print case info
    cited_ev = [s["evidence_id"] for s in steps if s.get("evidence_id")]
    print(f"{cid:7s} | {uid:8s} | status={status:10s} | audit_at={audit_at} | cited={set(cited_ev)}")
