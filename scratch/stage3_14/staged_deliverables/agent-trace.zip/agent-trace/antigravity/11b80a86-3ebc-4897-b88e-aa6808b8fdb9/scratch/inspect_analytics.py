import json

with open(r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main\dataset\evidence\records\service_resource_export_20260915_114455.json", "r", encoding="utf-8") as f:
    data = json.load(f)

profiles = data["service_exports"]["analytics_platform"]["profiles"]
for p in profiles:
    print(p)
