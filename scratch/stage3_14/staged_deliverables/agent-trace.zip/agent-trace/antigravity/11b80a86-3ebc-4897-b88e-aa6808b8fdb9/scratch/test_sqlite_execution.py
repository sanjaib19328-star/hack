"""
Test executing SQL snapshots with SQLite and querying by user identities.
"""

import os
import glob
import sqlite3
import csv
import json

repo_dir = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
dataset_dir = os.path.join(repo_dir, "dataset")

# Load email to uid
email_to_uid = {}
uid_to_emails = {}
with open(os.path.join(dataset_dir, "user_identities.csv"), encoding="utf-8") as f:
    for r in csv.DictReader(f):
        u = r["user_id"]
        e = r["email"].lower().strip()
        email_to_uid[e] = u
        uid_to_emails[u] = {e}

with open(os.path.join(dataset_dir, "user_audit_log.csv"), encoding="utf-8") as f:
    for r in csv.DictReader(f):
        u = r["user_id"]
        if r.get("field_name") == "email":
            if r.get("old_value"):
                e = r["old_value"].lower().strip()
                email_to_uid[e] = u
                if u in uid_to_emails: uid_to_emails[u].add(e)
            if r.get("new_value"):
                e = r["new_value"].lower().strip()
                email_to_uid[e] = u
                if u in uid_to_emails: uid_to_emails[u].add(e)

sql_files = glob.glob(os.path.join(dataset_dir, "**", "*.sql"), recursive=True)
print(f"Testing execution on {len(sql_files)} SQL files...")

successful_loads = 0
total_records = 0

for sf in sql_files:
    conn = sqlite3.connect(":memory:")
    cur = conn.cursor()
    try:
        with open(sf, "r", encoding="utf-8", errors="ignore") as f:
            sql_text = f.read()
        cur.executescript(sql_text)
        successful_loads += 1
        # List tables
        cur.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = [r[0] for r in cur.fetchall()]
        for t in tables:
            cur.execute(f"SELECT count(*) FROM {t}")
            cnt = cur.fetchone()[0]
            total_records += cnt
    except Exception as e:
        print(f"Error executing {os.path.basename(sf)}: {e}")
    finally:
        conn.close()

print(f"Successfully loaded {successful_loads}/{len(sql_files)} SQL snapshots, total table records: {total_records}")
