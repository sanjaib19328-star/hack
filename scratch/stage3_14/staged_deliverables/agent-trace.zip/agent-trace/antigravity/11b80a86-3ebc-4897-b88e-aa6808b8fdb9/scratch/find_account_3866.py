import os

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

matches = []
for root, dirs, files in os.walk(DATASET_DIR):
    for f in files:
        fpath = os.path.join(root, f)
        try:
            with open(fpath, "r", encoding="utf-8", errors="ignore") as fh:
                content = fh.read()
                if "account_3866" in content:
                    matches.append((os.path.relpath(fpath, DATASET_DIR), len(content)))
        except Exception as e:
            pass

print("Files containing 'account_3866':")
for m, sz in matches:
    print(f"  {m} ({sz} chars)")
