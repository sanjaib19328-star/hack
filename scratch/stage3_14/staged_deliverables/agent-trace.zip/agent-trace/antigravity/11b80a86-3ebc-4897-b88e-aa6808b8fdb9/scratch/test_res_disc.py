import csv
import json
import os
import sqlite3
from collections import defaultdict

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

# Load sample output
with open(os.path.join(DATASET_DIR, "sample_output.csv"), "r", encoding="utf-8") as f:
    sample_outs = {r["case_id"]: (r["deletion_status"], json.loads(r["steps_json"])) for r in csv.DictReader(f)}

# Load sample requests
with open(os.path.join(DATASET_DIR, "sample_deletion_requests.csv"), "r", encoding="utf-8") as f:
    sample_reqs = {r["case_id"]: r for r in csv.DictReader(f)}

# Load user identities & audit
with open(os.path.join(DATASET_DIR, "user_identities.csv"), "r", encoding="utf-8") as f:
    user_identities = list(csv.DictReader(f))
with open(os.path.join(DATASET_DIR, "user_audit_log.csv"), "r", encoding="utf-8") as f:
    user_audit = list(csv.DictReader(f))
with open(os.path.join(DATASET_DIR, "evidence_files.csv"), "r", encoding="utf-8") as f:
    evidence_manifest = list(csv.DictReader(f))

email_to_uid = {}
uid_to_emails = defaultdict(set)
uid_to_phones = defaultdict(set)
uid_to_names = defaultdict(set)

for u in user_identities:
    uid = u["user_id"]
    e = u["email"].lower()
    email_to_uid[e] = uid
    uid_to_emails[uid].add(e)
    if u.get("name"): uid_to_names[uid].add(u["name"].lower())
    if u.get("phone"): uid_to_phones[uid].add(u["phone"])

for a in user_audit:
    uid = a["user_id"]
    if a["field_name"] == "email":
        email_to_uid[a["old_value"].lower()] = uid
        uid_to_emails[uid].add(a["old_value"].lower())
        uid_to_emails[uid].add(a["new_value"].lower())
    elif a["field_name"] == "phone":
        uid_to_phones[uid].add(a["old_value"])
        uid_to_phones[uid].add(a["new_value"])

print("Testing resource discovery via evidence scans for all 32 cases...")

for cid in sorted(sample_reqs.keys(), key=lambda x: int(x.split("_")[1])):
    req = sample_reqs[cid]
    status, steps = sample_outs[cid]
    uid = email_to_uid.get(req["email"].lower())
    expected_res = set(s["resource_id"] for s in steps)
    
    # Let's see all evidence files captured at or before audit_at
    audit_at = req["audit_at"]
    # Which evidence file was cited in the ground truth?
    cited_evs = set(s["evidence_id"] for s in steps if s.get("evidence_id"))
    
    print(f"\n{cid} ({uid}): expected={sorted(expected_res)} | cited={cited_evs}")
