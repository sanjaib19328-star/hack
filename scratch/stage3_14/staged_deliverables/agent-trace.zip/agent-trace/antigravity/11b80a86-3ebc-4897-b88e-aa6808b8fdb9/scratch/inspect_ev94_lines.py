with open('hackerrank-orchestrate-october26-main/dataset/evidence/logs/resource_lookup_trace_20260926_103856.log') as f:
    lines = [line.strip() for line in f if line.strip()]

print(f"Total lines in evidence_94: {len(lines)}")
for l in lines[:20]:
    print(l)
