import os
import json
import csv
import re
import sqlite3
import pandas as pd
from collections import defaultdict

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

# 1. Load identities
users_df = pd.read_csv(os.path.join(DATASET_DIR, "user_identities.csv"))
audit_df = pd.read_csv(os.path.join(DATASET_DIR, "user_audit_log.csv"))
ef_df = pd.read_csv(os.path.join(DATASET_DIR, "evidence_files.csv"))
sys_act_df = pd.read_csv(os.path.join(DATASET_DIR, "system_activity.csv"))
sample_outs_df = pd.read_csv(os.path.join(DATASET_DIR, "sample_output.csv"))
sample_reqs_df = pd.read_csv(os.path.join(DATASET_DIR, "sample_deletion_requests.csv"))

email_to_uid = {}
uid_to_identities = defaultdict(dict)

for idx, r in users_df.iterrows():
    u = r['user_id']
    e = str(r['email']).lower()
    email_to_uid[e] = u
    uid_to_identities[u]['user_id'] = u
    uid_to_identities[u]['email'] = e
    uid_to_identities[u]['emails'] = {e}
    uid_to_identities[u]['name'] = str(r['name']).lower() if pd.notna(r['name']) else ""
    uid_to_identities[u]['names'] = {str(r['name']).lower()} if pd.notna(r['name']) else set()
    uid_to_identities[u]['phones'] = {str(r['phone'])} if pd.notna(r['phone']) else set()
    uid_to_identities[u]['email_hash'] = str(r['email_hash']) if pd.notna(r['email_hash']) else ""

for idx, r in audit_df.iterrows():
    u = r['user_id']
    if u not in uid_to_identities:
        uid_to_identities[u]['user_id'] = u
        uid_to_identities[u]['emails'] = set()
        uid_to_identities[u]['names'] = set()
        uid_to_identities[u]['phones'] = set()
    
    if r['field_name'] == 'email':
        if pd.notna(r['old_value']):
            v = str(r['old_value']).lower().strip()
            email_to_uid[v] = u
            uid_to_identities[u]['emails'].add(v)
        if pd.notna(r['new_value']):
            v = str(r['new_value']).lower().strip()
            email_to_uid[v] = u
            uid_to_identities[u]['emails'].add(v)
    elif r['field_name'] == 'phone':
        if pd.notna(r['old_value']): uid_to_identities[u]['phones'].add(str(r['old_value']).strip())
        if pd.notna(r['new_value']): uid_to_identities[u]['phones'].add(str(r['new_value']).strip())
    elif r['field_name'] == 'name':
        if pd.notna(r['old_value']): uid_to_identities[u]['names'].add(str(r['old_value']).lower().strip())
        if pd.notna(r['new_value']): uid_to_identities[u]['names'].add(str(r['new_value']).lower().strip())

# Order definitions
OP_ORDER = {
    'FINDING': {
        'REPORT_REMAINING_RECORD': 1,
        'REPORT_EXPOSED_PII': 2,
        'REPORT_ACTIVE_DATA_FLOW': 3,
        'REPORT_RESTORE_RISK': 4
    },
    'REMEDIATION': {
        'DISABLE_DATA_FLOW': 1,
        'BLOCK_RESTORE': 2,
        'DELETE_RECORD': 3,
        'REDACT_RECORD': 4,
        'ANONYMIZE_RECORD': 5
    },
    'VERIFICATION': {
        'VERIFY_RECORD_ABSENT': 1,
        'VERIFY_RECORD_PRESENT': 2,
        'VERIFY_RECORD_REDACTED': 3,
        'VERIFY_RECORD_ANONYMIZED': 4,
        'VERIFY_DATA_FLOW_DISABLED': 5,
        'VERIFY_RESTORE_BLOCKED': 6
    }
}

PHASE_ORDER = {'FINDING': 1, 'REMEDIATION': 2, 'VERIFICATION': 3}

def sort_steps(steps):
    return sorted(
        steps,
        key=lambda s: (
            PHASE_ORDER[s['phase']],
            OP_ORDER[s['phase']][s['operation']],
            s['system_id'],
            s['resource_id']
        )
    )

print("Ordering engine verified.")
