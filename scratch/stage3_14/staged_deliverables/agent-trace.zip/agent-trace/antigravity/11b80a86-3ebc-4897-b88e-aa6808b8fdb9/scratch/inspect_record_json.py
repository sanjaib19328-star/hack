import sqlite3
import json

con = sqlite3.connect(":memory:")
cur = con.cursor()
with open(r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main\dataset\evidence\databases\customer_data_read_replica_20260613.sql", "r", encoding="utf-8") as f:
    cur.executescript(f.read())

rows = cur.execute("SELECT resource_id, origin_system, collection_name, record_json FROM customer_data_primary LIMIT 5").fetchall()
for r in rows:
    print(r[0], r[1], r[2], json.loads(r[3]))
con.close()
