with open(r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main\dataset\evidence\logs\resource_lookup_trace_20260926_103856.log", "r", encoding="utf-8") as f:
    lines = f.readlines()

for l in lines:
    if "user_48" in l or "user_50" in l or "akosua" in l or "ren" in l:
        print(l.strip())
