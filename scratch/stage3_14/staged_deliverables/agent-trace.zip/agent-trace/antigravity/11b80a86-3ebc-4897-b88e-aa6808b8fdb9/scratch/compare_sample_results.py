import csv
import json
import pandas as pd

expected_df = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_output.csv')
actual_df = pd.read_csv('hackerrank-orchestrate-october26-main/sample_test_output.csv')

print(f"Expected rows: {len(expected_df)}, Actual rows: {len(actual_df)}")

status_matches = 0
step_matches = 0
total_cases = len(expected_df)

for idx, exp_row in expected_df.iterrows():
    cid = exp_row['case_id']
    act_row = actual_df[actual_df['case_id'] == cid].iloc[0]
    
    exp_status = exp_row['deletion_status']
    act_status = act_row['deletion_status']
    
    exp_steps = json.loads(exp_row['steps_json'])
    act_steps = json.loads(act_row['steps_json'])
    
    s_match = (exp_status == act_status)
    if s_match: status_matches += 1
    
    steps_exact = (exp_steps == act_steps)
    if steps_exact: step_matches += 1
    
    match_str = "EXACT MATCH" if (s_match and steps_exact) else "MISMATCH"
    print(f"{cid}: {match_str} | exp_status={exp_status}, act_status={act_status} | exp_steps={len(exp_steps)}, act_steps={len(act_steps)}")
    if not steps_exact:
        print(f"   Expected: {exp_steps}")
        print(f"   Actual:   {act_steps}")

print(f"\nSummary:")
print(f"Status Accuracy: {status_matches}/{total_cases} ({status_matches/total_cases*100:.1f}%)")
print(f"Exact Steps Accuracy: {step_matches}/{total_cases} ({step_matches/total_cases*100:.1f}%)")
