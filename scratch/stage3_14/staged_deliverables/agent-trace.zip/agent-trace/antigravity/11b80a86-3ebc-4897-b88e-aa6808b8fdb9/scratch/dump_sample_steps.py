import pandas as pd
import json

df = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_output.csv')
for idx, row in df.iterrows():
    steps = json.loads(row['steps_json'])
    print(f"{row['case_id']}: {row['deletion_status']} ({len(steps)} steps)")
    for s in steps:
        print(f"  step {s['step_no']}: phase={s['phase']}, sys={s['system_id']}, op={s['operation']}, res={s['resource_id']}, state={s['state']}, ev={s['evidence_id']}")
