"""
Complete Grounded Resource and Evidence Resolver.
"""

import os
import glob
import re
import json
import csv
import sqlite3
from collections import defaultdict

repo_dir = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
dataset_dir = os.path.join(repo_dir, "dataset")

# 1. Identity graph
email_to_uid = {}
uid_to_emails = defaultdict(set)
uid_to_names = defaultdict(set)
uid_to_phones = defaultdict(set)

with open(os.path.join(dataset_dir, "user_identities.csv"), encoding="utf-8") as f:
    for r in csv.DictReader(f):
        u = r["user_id"]
        e = r["email"].lower().strip()
        email_to_uid[e] = u
        uid_to_emails[u].add(e)
        if r.get("phone"): uid_to_phones[u].add(r["phone"].strip())
        if r.get("name"): uid_to_names[u].add(r["name"].lower().strip())

with open(os.path.join(dataset_dir, "user_audit_log.csv"), encoding="utf-8") as f:
    for r in csv.DictReader(f):
        u = r["user_id"]
        fn = r.get("field_name")
        if fn == "email":
            if r.get("old_value"):
                e = r["old_value"].lower().strip()
                email_to_uid[e] = u
                uid_to_emails[u].add(e)
            if r.get("new_value"):
                e = r["new_value"].lower().strip()
                email_to_uid[e] = u
                uid_to_emails[u].add(e)

# Also check for user_01 -> account_001 convention if user_id is user_XX
for u in uid_to_emails.keys():
    m = re.match(r"user_0*(\d+)", u)
    if m:
        num = int(m.group(1))
        if num <= 10:
            acc_id = f"account_{num:03d}"
            # print convention
            pass

# 2. Ingest Evidence Files Manifest
with open(os.path.join(dataset_dir, "evidence_files.csv"), encoding="utf-8") as f:
    manifest = list(csv.DictReader(f))

# Let's inspect how each sample case matches expected steps!
with open(os.path.join(dataset_dir, "sample_output.csv"), encoding="utf-8") as f:
    sample_truth = {r["case_id"]: (r["deletion_status"], json.loads(r["steps_json"])) for r in csv.DictReader(f)}

with open(os.path.join(dataset_dir, "sample_deletion_requests.csv"), encoding="utf-8") as f:
    sample_reqs = {r["case_id"]: r for r in csv.DictReader(f)}

print(f"Sample requests count: {len(sample_reqs)}")
