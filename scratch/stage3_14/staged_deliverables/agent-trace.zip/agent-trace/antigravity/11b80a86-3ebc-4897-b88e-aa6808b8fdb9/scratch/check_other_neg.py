import csv
import json
import os

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

with open(os.path.join(DATASET_DIR, "deletion_requests.csv"), "r", encoding="utf-8") as f:
    full_reqs = list(csv.DictReader(f))

suspicious = []
for r in full_reqs:
    cid = int(r["case_id"].split("_")[1])
    if cid >= 533 and cid <= 542:
        continue # we know these 10
    text = r["request_text"].lower()
    for neg in ["not", "don't", "dont", "leave", "keep", "without", "rectif", "correct", "access", "copy", "export", "download"]:
        if neg in text:
            suspicious.append((r["case_id"], neg, r["request_text"]))
            break

print(f"Suspicious cases outside 533-542: {len(suspicious)}")
for cid, neg, txt in suspicious:
    print(f"[{cid}] (matched '{neg}') {txt}")
