import json

with open(r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main\dataset\evidence\records\service_resource_export_20260915_114455.json", "r", encoding="utf-8") as f:
    data = json.load(f)

print("Keys in service_resource_export:", data.get("service_exports", {}).keys())

for service, items in data.get("service_exports", {}).items():
    print(f"\n--- Service: {service} ---")
    if isinstance(items, dict):
        for subk, subl in items.items():
            print(f"  Subkey: {subk} ({len(subl)} items)")
            # search for user_27 or ananya
            for obj in subl:
                s_obj = str(obj)
                if "27" in s_obj or "ananya" in s_obj or "3866" in s_obj or "3830" in s_obj:
                    print(f"    Match in {subk}: {obj}")
    elif isinstance(items, list):
        print(f"  List ({len(items)} items)")
        for obj in items:
            s_obj = str(obj)
            if "27" in s_obj or "ananya" in s_obj or "3866" in s_obj or "3830" in s_obj:
                print(f"    Match: {obj}")
