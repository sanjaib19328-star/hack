import os
import json
import csv
import re
import pandas as pd
from collections import defaultdict

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

# Load ground truth
expected_df = pd.read_csv(os.path.join(DATASET_DIR, "sample_output.csv"))
sample_reqs_df = pd.read_csv(os.path.join(DATASET_DIR, "sample_deletion_requests.csv"))

# Inspect where account_4857 comes from for case_31
for root, dirs, files in os.walk(DATASET_DIR):
    for f in files:
        p = os.path.join(root, f)
        try:
            with open(p, 'r', encoding='utf-8', errors='ignore') as fh:
                if 'account_4857' in fh.read():
                    print('account_4857 found in:', f)
        except: pass
