import os
import json
import re
import pandas as pd
from collections import defaultdict

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

ef = pd.read_csv(os.path.join(DATASET_DIR, "evidence_files.csv"))
sre_files = ef[ef['origin'] == 'service_resource_export']

all_sre_users = defaultdict(set)
for idx, r in sre_files.iterrows():
    fpath = os.path.join(DATASET_DIR, r['file_path'])
    fid = r['file_id']
    with open(fpath, 'r', encoding='utf-8') as f:
        d = json.load(f)
    txt = json.dumps(d)
    for m in re.finditer(r'(user_\d+)', txt):
        all_sre_users[m.group(1)].add(fid)

print(f"Total unique users found across service resource exports: {len(all_sre_users)}")
print("Sample mapped users:", list(all_sre_users.keys())[:20])
