import os
import glob

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")
log_files = glob.glob(os.path.join(DATASET_DIR, "evidence", "logs", "*.log"))
print(f"Total log files: {len(log_files)}")

log_types = {}
for lf in log_files:
    fname = os.path.basename(lf)
    prefix = "_".join(fname.split("_")[:-1])
    if prefix not in log_types:
        log_types[prefix] = lf

for p, lf in log_types.items():
    print(f"\n--- Log prefix {p} ({os.path.basename(lf)}) ---")
    with open(lf, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip()][:3]
    for l in lines:
        print(f"  {l[:140]}")
