import pandas as pd
from collections import defaultdict

reqs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/deletion_requests.csv')
sample_reqs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_deletion_requests.csv')
users = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/user_identities.csv')
audit_log = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/user_audit_log.csv')
ef = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/evidence_files.csv')

email_to_uid = {}
for idx, r in users.iterrows():
    email_to_uid[r['email'].lower()] = r['user_id']
for idx, r in audit_log.iterrows():
    if pd.notna(r['old_value']) and '@' in str(r['old_value']):
        email_to_uid[str(r['old_value']).lower()] = r['user_id']
    if pd.notna(r['new_value']) and '@' in str(r['new_value']):
        email_to_uid[str(r['new_value']).lower()] = r['user_id']

reqs['user_id'] = reqs['email'].str.lower().map(email_to_uid)
batches = reqs.groupby('audit_at')
print(f"Total batches in deletion_requests: {len(batches)}")

# Check each batch's size and user IDs
for aat, group in list(batches)[:10]:
    cids = group['case_id'].tolist()
    uids = group['user_id'].tolist()
    print(f"\nBatch audit_at={aat} ({len(group)} cases):")
    print(f"  Cases: {cids}")
    print(f"  Users: {uids}")
