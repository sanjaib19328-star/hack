import pandas as pd
import json

reqs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_deletion_requests.csv')
outs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_output.csv')
users = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/user_identities.csv')
audit_log = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/user_audit_log.csv')

# Build mapping from email -> user_id
email_to_uid = {}
for idx, r in users.iterrows():
    email_to_uid[r['email'].lower()] = r['user_id']
for idx, r in audit_log.iterrows():
    if pd.notna(r['old_value']) and '@' in str(r['old_value']):
        email_to_uid[str(r['old_value']).lower()] = r['user_id']
    if pd.notna(r['new_value']) and '@' in str(r['new_value']):
        email_to_uid[str(r['new_value']).lower()] = r['user_id']

merged = pd.merge(reqs, outs, on='case_id')
for idx, r in merged.iterrows():
    steps = json.loads(r['steps_json'])
    ev_ids = [s['evidence_id'] for s in steps if s['evidence_id']]
    uid = email_to_uid.get(r['email'].lower(), "NOT_FOUND")
    print(f"{r['case_id']} | uid={uid} | audit_at={r['audit_at']} | status={r['deletion_status']} | evs={set(ev_ids)}")
