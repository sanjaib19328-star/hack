import os
import json
import csv
import re
import pandas as pd
from collections import defaultdict

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

# Load sample output
sample_outs = pd.read_csv(os.path.join(DATASET_DIR, "sample_output.csv"))
sample_reqs = pd.read_csv(os.path.join(DATASET_DIR, "sample_deletion_requests.csv"))

ground_truth = {}
for idx, r in sample_outs.iterrows():
    ground_truth[r['case_id']] = {
        'status': r['deletion_status'],
        'steps': json.loads(r['steps_json'])
    }

print(f"Loaded ground truth for {len(ground_truth)} sample cases.")
