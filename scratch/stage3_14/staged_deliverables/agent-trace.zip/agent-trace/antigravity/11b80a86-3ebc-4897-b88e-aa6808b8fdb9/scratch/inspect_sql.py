import os
import glob
import sqlite3

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

# Inspect a few SQL files
sql_files = glob.glob(os.path.join(DATASET_DIR, "evidence", "databases", "*.sql"))
print(f"Total SQL files: {len(sql_files)}")

# Check tables in one of each type of SQL file
sql_types = {}
for sf in sql_files:
    base = os.path.basename(sf)
    prefix = "_".join(base.split("_")[:-1])
    if prefix not in sql_types:
        sql_types[prefix] = sf

for prefix, sf in sql_types.items():
    print(f"\n--- SQL Type: {prefix} ({os.path.basename(sf)}) ---")
    with open(sf, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip() and not line.startswith("--")]
    create_tables = [l for l in lines if l.upper().startswith("CREATE TABLE")]
    print(f"  Create tables: {create_tables}")
    sample_inserts = [l for l in lines if l.upper().startswith("INSERT INTO")][:2]
    for ins in sample_inserts:
        print(f"  Insert: {ins[:120]}")
