import os
import json
import re
import pandas as pd
from collections import defaultdict

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

ef = pd.read_csv(os.path.join(DATASET_DIR, "evidence_files.csv"))
bundles = ef[ef['origin'] == 'records_assurance_snapshot_bundle']

all_bundle_users = defaultdict(set)
for idx, r in bundles.iterrows():
    fpath = os.path.join(DATASET_DIR, r['file_path'])
    fid = r['file_id']
    with open(fpath, 'r', encoding='utf-8') as f:
        d = json.load(f)
    for s in d.get('snapshots', []):
        for rec in s.get('records', []):
            rec_str = str(rec)
            for m in re.finditer(r'(user_\d+)', rec_str):
                all_bundle_users[m.group(1)].add(fid)

print(f"Total unique users found across snapshot bundles: {len(all_bundle_users)}")
print("Sample mapped users:", list(all_bundle_users.keys())[:20])
