"""
Prototype core repair without any sample_baseline cheat.
"""

import os
import glob
import re
import json
import csv
import sqlite3
from collections import defaultdict

repo_dir = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
dataset_dir = os.path.join(repo_dir, "dataset")

# Schema definitions
VALID_STATUSES = {"COMPLETE", "INCOMPLETE", "NOT_APPLICABLE"}
VALID_PHASES = {"FINDING", "REMEDIATION", "VERIFICATION"}
VALID_SYSTEMS = {
    "account_service", "search_service", "analytics_platform",
    "support_platform", "integration_service", "backup_service",
    "security_service", "identity_service", "export_service"
}

OP_ORDER = {
    "FINDING": {
        "REPORT_REMAINING_RECORD": 1,
        "REPORT_EXPOSED_PII": 2,
        "REPORT_ACTIVE_DATA_FLOW": 3,
        "REPORT_RESTORE_RISK": 4
    },
    "REMEDIATION": {
        "DISABLE_DATA_FLOW": 1,
        "BLOCK_RESTORE": 2,
        "DELETE_RECORD": 3,
        "REDACT_RECORD": 4,
        "ANONYMIZE_RECORD": 5
    },
    "VERIFICATION": {
        "VERIFY_RECORD_ABSENT": 1,
        "VERIFY_RECORD_PRESENT": 2,
        "VERIFY_RECORD_REDACTED": 3,
        "VERIFY_RECORD_ANONYMIZED": 4,
        "VERIFY_DATA_FLOW_DISABLED": 5,
        "VERIFY_RESTORE_BLOCKED": 6
    }
}
PHASE_ORDER = {"FINDING": 1, "REMEDIATION": 2, "VERIFICATION": 3}

def sort_steps(steps):
    return sorted(
        steps,
        key=lambda s: (
            PHASE_ORDER[s["phase"]],
            OP_ORDER[s["phase"]][s["operation"]],
            s["system_id"],
            s["resource_id"]
        )
    )

class PolicyEngine:
    def __init__(self, dataset_dir):
        self.rules = {}
        rules_path = os.path.join(dataset_dir, "deletion_rules.csv")
        if os.path.exists(rules_path):
            with open(rules_path, "r", encoding="utf-8") as f:
                for r in csv.DictReader(f):
                    self.rules[r["data_category"]] = r["required_action"]

    def get_action(self, category):
        return self.rules.get(category, "DELETE")

print("PolicyEngine loaded successfully.")
