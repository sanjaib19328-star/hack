import pandas as pd
import json
from collections import defaultdict

sample_reqs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_deletion_requests.csv')
sample_outs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_output.csv')
users = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/user_identities.csv')
audit_log = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/user_audit_log.csv')
sys_act = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/system_activity.csv')

email_to_uid = {}
uid_to_emails = defaultdict(set)
uid_to_names = defaultdict(set)
uid_to_phones = defaultdict(set)

for idx, r in users.iterrows():
    u = r['user_id']
    e = str(r['email']).lower()
    email_to_uid[e] = u
    uid_to_emails[u].add(e)
    if pd.notna(r['name']): uid_to_names[u].add(str(r['name']).lower())
    if pd.notna(r['phone']): uid_to_phones[u].add(str(r['phone']))

for idx, r in audit_log.iterrows():
    u = r['user_id']
    if r['field_name'] == 'email':
        if pd.notna(r['old_value']):
            email_to_uid[str(r['old_value']).lower()] = u
            uid_to_emails[u].add(str(r['old_value']).lower())
        if pd.notna(r['new_value']):
            email_to_uid[str(r['new_value']).lower()] = u
            uid_to_emails[u].add(str(r['new_value']).lower())
    elif r['field_name'] == 'phone':
        if pd.notna(r['old_value']): uid_to_phones[u].add(str(r['old_value']))
        if pd.notna(r['new_value']): uid_to_phones[u].add(str(r['new_value']))

merged = pd.merge(sample_reqs, sample_outs, on='case_id')

all_res_findings = []

for idx, r in merged.iterrows():
    cid = r['case_id']
    uid = email_to_uid[r['email'].lower()]
    emails = uid_to_emails[uid]
    phones = uid_to_phones[uid]
    names = uid_to_names[uid]
    
    steps = json.loads(r['steps_json'])
    expected_resources = set(s['resource_id'] for s in steps)
    
    # Let's see how each expected resource is linked
    for res in expected_resources:
        # Check system_activity
        sa_matches = sys_act[sys_act['resource_id'] == res]
        # Check if user / email in details or if in window
        linked_by = []
        if any(uid in str(d) for d in sa_matches['details']): linked_by.append('sa_uid')
        if any(any(e in str(d).lower() for e in emails) for d in sa_matches['details']): linked_by.append('sa_email')
        
        # Check if in request time window
        t_start = r['requested_at']
        t_end = r['reported_at']
        in_win = sa_matches[(sa_matches['event_time'] >= t_start) & (sa_matches['event_time'] <= t_end)]
        if len(in_win) > 0: linked_by.append(f'sa_window({len(in_win)})')
        
        all_res_findings.append({
            'cid': cid,
            'uid': uid,
            'res': res,
            'linked_by': linked_by,
            'sa_count': len(sa_matches)
        })

df_res = pd.DataFrame(all_res_findings)
print(f"Total resource associations in sample cases: {len(df_res)}")
unlinked = df_res[df_res['linked_by'].apply(len) == 0]
print(f"Unlinked by system_activity: {len(unlinked)}")
print(unlinked.head(20))
