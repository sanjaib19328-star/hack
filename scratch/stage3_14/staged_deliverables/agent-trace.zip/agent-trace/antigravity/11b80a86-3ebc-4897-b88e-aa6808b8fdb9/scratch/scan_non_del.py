import csv
import json
import os

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

with open(os.path.join(DATASET_DIR, "deletion_requests.csv"), "r", encoding="utf-8") as f:
    full_reqs = list(csv.DictReader(f))

# Let's inspect all cases towards the end (case_518 to case_550? What is the range of case_id?)
case_ids = [r["case_id"] for r in full_reqs]
print(f"Total cases: {len(case_ids)}, min case: {case_ids[0]}, max case: {case_ids[-1]}")

# Let's search for any request containing phrases like:
# "keep", "active", "portable", "download", "invoice", "update", "replace", "opt-out", "marketing", "newsletter", "leave", "continue"
phrases = ["keep", "active", "portable", "download", "invoice", "replace", "opt-out", "marketing", "newsletter", "leave", "continue", "access", "correction", "rectif"]

with open("scratch/non_del_scan.txt", "w", encoding="utf-8") as out:
    for r in full_reqs:
        text_lower = r["request_text"].lower()
        if any(p in text_lower for p in phrases):
            out.write(f"[{r['case_id']}] {r['request_text']}\n")
print("Done scanning phrases")
