import os
import json
import pandas as pd
import sqlite3

reqs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/deletion_requests.csv')
sample_reqs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_deletion_requests.csv')
users = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/user_identities.csv')
audit_log = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/user_audit_log.csv')
ef = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/evidence_files.csv')
sys_act = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/system_activity.csv')

# Build mapping from email -> user_id, and also collect all aliases/phones/names
email_to_uid = {}
uid_to_emails = {}
for idx, r in users.iterrows():
    u = r['user_id']
    e = str(r['email']).lower()
    email_to_uid[e] = u
    uid_to_emails.setdefault(u, set()).add(e)

for idx, r in audit_log.iterrows():
    u = r['user_id']
    if pd.notna(r['old_value']) and '@' in str(r['old_value']):
        e = str(r['old_value']).lower()
        email_to_uid[e] = u
        uid_to_emails.setdefault(u, set()).add(e)
    if pd.notna(r['new_value']) and '@' in str(r['new_value']):
        e = str(r['new_value']).lower()
        email_to_uid[e] = u
        uid_to_emails.setdefault(u, set()).add(e)

print(f"Total requests in deletion_requests: {len(reqs)}")
uids_in_reqs = []
missing_emails = []
for idx, r in reqs.iterrows():
    e = str(r['email']).lower()
    if e in email_to_uid:
        uids_in_reqs.append((r['case_id'], email_to_uid[e], r['audit_at']))
    else:
        missing_emails.append((r['case_id'], e))

print(f"Resolved UIDs: {len(uids_in_reqs)}, Missing emails: {len(missing_emails)}")
if missing_emails:
    print("Sample missing emails:", missing_emails[:5])
