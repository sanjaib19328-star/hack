import pandas as pd
import json

reqs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/deletion_requests.csv')
print(reqs.head(10))
print(reqs.tail(15))
