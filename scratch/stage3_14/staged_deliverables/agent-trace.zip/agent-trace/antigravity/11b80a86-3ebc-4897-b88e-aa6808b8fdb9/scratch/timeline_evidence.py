import csv
import os

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

with open(os.path.join(DATASET_DIR, "evidence_files.csv"), "r", encoding="utf-8") as f:
    evs = list(csv.DictReader(f))

# sort by captured_at
evs_sorted = sorted(evs, key=lambda x: x["captured_at"])
print("Timeline of evidence files:")
for e in evs_sorted:
    print(f"  {e['captured_at']} | {e['file_id']:12s} | {e['origin']:35s} | {e['file_path']}")
