import pandas as pd
df = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/system_activity.csv')
print(df.head(10)[['activity_id', 'event_time', 'event_type', 'resource_id', 'reported_result', 'details']])
