import csv
import json
import os
import glob
from collections import defaultdict

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

with open(os.path.join(DATASET_DIR, "sample_output.csv"), "r", encoding="utf-8") as f:
    sample_outs = {r["case_id"]: (r["deletion_status"], json.loads(r["steps_json"])) for r in csv.DictReader(f)}

with open(os.path.join(DATASET_DIR, "sample_deletion_requests.csv"), "r", encoding="utf-8") as f:
    sample_reqs = {r["case_id"]: r for r in csv.DictReader(f)}

with open(os.path.join(DATASET_DIR, "user_identities.csv"), "r", encoding="utf-8") as f:
    user_identities = list(csv.DictReader(f))

with open(os.path.join(DATASET_DIR, "user_audit_log.csv"), "r", encoding="utf-8") as f:
    user_audit = list(csv.DictReader(f))

with open(os.path.join(DATASET_DIR, "evidence_files.csv"), "r", encoding="utf-8") as f:
    evidence_manifest = list(csv.DictReader(f))

email_to_uid = {}
uid_to_emails = defaultdict(set)
uid_to_names = defaultdict(set)
uid_to_phones = defaultdict(set)
for u in user_identities:
    uid = u["user_id"]
    e = u["email"].lower()
    email_to_uid[e] = uid
    uid_to_emails[uid].add(e)
    if u.get("name"): uid_to_names[uid].add(u["name"].lower())
    if u.get("phone"): uid_to_phones[uid].add(u["phone"])

for a in user_audit:
    uid = a["user_id"]
    if a["field_name"] == "email":
        email_to_uid[a["old_value"].lower()] = uid
        uid_to_emails[uid].add(a["old_value"].lower())
        uid_to_emails[uid].add(a["new_value"].lower())
    elif a["field_name"] == "phone":
        uid_to_phones[uid].add(a["old_value"])
        uid_to_phones[uid].add(a["new_value"])
    elif a["field_name"] == "name":
        uid_to_names[uid].add(a["old_value"].lower())
        uid_to_names[uid].add(a["new_value"].lower())

# Read all evidence files text into memory
print("Loading evidence file contents...")
ev_contents = {}
for ev in evidence_manifest:
    fid = ev["file_id"]
    fpath = os.path.join(DATASET_DIR, ev["file_path"])
    ext = os.path.splitext(fpath)[1].lower()
    text = ""
    if ext in [".json", ".log", ".sql", ".txt", ".csv"]:
        with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read()
    elif ext == ".pdf":
        import pypdf
        reader = pypdf.PdfReader(fpath)
        for page in reader.pages:
            text += page.extract_text() + "\n"
    ev_contents[fid] = (ev, text)

print("Matching evidence for sample cases...")
for cid in sorted(sample_reqs.keys(), key=lambda x: int(x.split("_")[1])):
    req = sample_reqs[cid]
    status, steps = sample_outs[cid]
    uid = email_to_uid.get(req["email"].lower())
    audit_at = req["audit_at"]
    
    # Ground truth evidence IDs cited in sample_output
    actual_evs = set(s["evidence_id"] for s in steps if s.get("evidence_id"))
    
    # Find all evidence files captured at or before audit_at that contain uid or emails
    matching_evs = []
    identifiers = list(uid_to_emails[uid]) + [uid]
    for fid, (ev, text) in ev_contents.items():
        if ev["captured_at"] <= audit_at:
            for ident in identifiers:
                if ident in text or ident.lower() in text.lower():
                    matching_evs.append(fid)
                    break
    
    # Also check if actual resources match
    step_res = set(s["resource_id"] for s in steps)
    matching_by_res = []
    for fid, (ev, text) in ev_contents.items():
        if ev["captured_at"] <= audit_at:
            if any(res in text for res in step_res):
                matching_by_res.append(fid)

    print(f"Case {cid} ({uid}): actual cited={actual_evs} | matching by ident={set(matching_evs)} | matching by res={set(matching_by_res)}")
