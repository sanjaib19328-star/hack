import json
import pandas as pd

df = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_output.csv')

valid_systems = {'account_service', 'search_service', 'analytics_platform', 'support_platform', 'integration_service', 'backup_service', 'security_service', 'identity_service', 'export_service'}

for idx, r in df.iterrows():
    cid = r['case_id']
    status = r['deletion_status']
    steps = json.loads(r['steps_json'])
    
    # check step_no sequential 1..N
    for i, s in enumerate(steps):
        assert s['step_no'] == i + 1, f"{cid}: step_no mismatch {s['step_no']} != {i+1}"
        assert s['system_id'] in valid_systems, f"{cid}: invalid system {s['system_id']}"
        
        # Check evidence_id rule:
        if status == 'COMPLETE':
            assert s['evidence_id'] != '', f"{cid}: COMPLETE step {s['step_no']} has empty evidence_id"
            assert s['phase'] == 'VERIFICATION', f"{cid}: COMPLETE has phase {s['phase']}"
        elif status == 'INCOMPLETE':
            if s['phase'] == 'FINDING':
                assert s['evidence_id'] != '', f"{cid}: FINDING has empty evidence_id"
            else:
                assert s['evidence_id'] == '', f"{cid}: {s['phase']} has non-empty evidence_id: {s['evidence_id']}"

print("ALL sample output steps strictly adhere to these exact constraints!")
