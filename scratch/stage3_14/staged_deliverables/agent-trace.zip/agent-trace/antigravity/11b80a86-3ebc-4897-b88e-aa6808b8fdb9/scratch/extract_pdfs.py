import os
import pypdf

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

pdf_files = [
    "evidence/documents/account_history_report_20260718.pdf",
    "evidence/documents/legal_retention_register_20260529.pdf",
    "evidence/documents/security_retention_extract.pdf",
    "evidence/documents/delivery_correction_attachment.pdf"
]

for p in pdf_files:
    full_path = os.path.join(DATASET_DIR, p)
    print(f"\n==================== {p} ====================")
    try:
        reader = pypdf.PdfReader(full_path)
        for idx, page in enumerate(reader.pages):
            text = page.extract_text()
            print(f"--- Page {idx+1} ---")
            print(text[:1000])
    except Exception as e:
        print("Error reading PDF:", e)
