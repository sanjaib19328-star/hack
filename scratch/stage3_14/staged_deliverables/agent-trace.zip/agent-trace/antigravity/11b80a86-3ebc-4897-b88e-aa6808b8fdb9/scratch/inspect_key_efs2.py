import pandas as pd
import json

ef = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/evidence_files.csv')
print(ef.head(10))

for eid in ['evidence_54', 'evidence_56', 'evidence_92', 'evidence_94', 'evidence_01', 'evidence_03', 'evidence_05', 'evidence_51']:
    row = ef[ef['file_id'] == eid].iloc[0]
    print(f"{eid}: origin={row['origin']}, cap={row['captured_at']}, file={row['file_path']}")
