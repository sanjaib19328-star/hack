import pandas as pd

reqs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/deletion_requests.csv')
sample_reqs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_deletion_requests.csv')
ef = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/evidence_files.csv')

# Group requests by audit_at
req_batches = reqs.groupby('audit_at').size().reset_index(name='count')
print("Total distinct audit_at timestamps in full requests:", len(req_batches))

# Check for each audit_at, what evidence file was captured at or <= audit_at within a 2-hour window
matches = []
for idx, r in req_batches.iterrows():
    aat = r['audit_at']
    # find evidence files captured within 3 hours prior to or at aat
    sub_ef = ef[(ef['captured_at'] <= aat)].sort_values('captured_at', ascending=False)
    if len(sub_ef) > 0:
        latest = sub_ef.iloc[0]
        matches.append((aat, r['count'], latest['file_id'], latest['origin'], latest['captured_at']))

df_m = pd.DataFrame(matches, columns=['audit_at', 'req_count', 'latest_file_id', 'origin', 'captured_at'])
print(df_m.head(25))
