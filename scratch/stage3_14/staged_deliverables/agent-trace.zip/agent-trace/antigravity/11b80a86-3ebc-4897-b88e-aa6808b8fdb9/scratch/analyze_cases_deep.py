import csv
import json
import os

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

# Load sample requests
with open(os.path.join(DATASET_DIR, "sample_deletion_requests.csv"), "r", encoding="utf-8") as f:
    sample_reqs = {r["case_id"]: r for r in csv.DictReader(f)}

# Load sample outputs
with open(os.path.join(DATASET_DIR, "sample_output.csv"), "r", encoding="utf-8") as f:
    sample_outs = {r["case_id"]: (r["deletion_status"], json.loads(r["steps_json"])) for r in csv.DictReader(f)}

# Load user identities
with open(os.path.join(DATASET_DIR, "user_identities.csv"), "r", encoding="utf-8") as f:
    user_identities = list(csv.DictReader(f))

# Load user audit log
with open(os.path.join(DATASET_DIR, "user_audit_log.csv"), "r", encoding="utf-8") as f:
    user_audit = list(csv.DictReader(f))

# Load system activity
with open(os.path.join(DATASET_DIR, "system_activity.csv"), "r", encoding="utf-8") as f:
    system_activity = list(csv.DictReader(f))

# Load evidence files manifest
with open(os.path.join(DATASET_DIR, "evidence_files.csv"), "r", encoding="utf-8") as f:
    evidence_manifest = {r["file_id"]: r for r in csv.DictReader(f)}

print(f"Loaded identities: {len(user_identities)}, audits: {len(user_audit)}, activities: {len(system_activity)}")

# For each sample case, let's see which user_id matches
email_to_user = {}
for u in user_identities:
    email_to_user[u["email"].lower()] = u["user_id"]

# Also map old emails from audit log
for a in user_audit:
    if a["field_name"] == "email":
        email_to_user[a["old_value"].lower()] = a["user_id"]

for cid in sorted(sample_reqs.keys(), key=lambda x: int(x.split("_")[1])):
    req = sample_reqs[cid]
    status, steps = sample_outs[cid]
    uid = email_to_user.get(req["email"].lower())
    print(f"\nCase {cid}: email={req['email']} -> user_id={uid}, audit_at={req['audit_at']}, status={status}")
    print(f"  Sample Steps count: {len(steps)}")
    for s in steps:
        ev_info = evidence_manifest.get(s["evidence_id"], {})
        ev_file = ev_info.get("file_path", "")
        ev_cap = ev_info.get("captured_at", "")
        print(f"    [{s['phase']}] sys={s['system_id']} res={s['resource_id']} op={s['operation']} st={s['state']} ev={s['evidence_id']} ({ev_file} @ {ev_cap})")
