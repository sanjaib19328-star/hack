import pandas as pd
df = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/system_activity.csv')
print(df['event_type'].value_counts())
