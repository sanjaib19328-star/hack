import os
import json
import re
import pandas as pd
from collections import defaultdict

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

users_df = pd.read_csv(os.path.join(DATASET_DIR, "user_identities.csv"))
audit_df = pd.read_csv(os.path.join(DATASET_DIR, "user_audit_log.csv"))
ef = pd.read_csv(os.path.join(DATASET_DIR, "evidence_files.csv"))
sre_files = ef[ef['origin'] == 'service_resource_export']

uid_to_emails = defaultdict(set)
for idx, r in users_df.iterrows():
    uid_to_emails[r['user_id']].add(str(r['email']).lower().strip())
for idx, r in audit_df.iterrows():
    if r['field_name'] == 'email':
        if pd.notna(r['old_value']): uid_to_emails[r['user_id']].add(str(r['old_value']).lower().strip())
        if pd.notna(r['new_value']): uid_to_emails[r['user_id']].add(str(r['new_value']).lower().strip())

found_users = set()
for idx, r in sre_files.iterrows():
    fpath = os.path.join(DATASET_DIR, r['file_path'])
    with open(fpath, 'r', encoding='utf-8') as f:
        txt = f.read().lower()
    for uid, emails in uid_to_emails.items():
        if uid in txt or any(e in txt for e in emails):
            found_users.add(uid)

print(f"Users found in service_resource_export (by uid + emails): {len(found_users)}")
