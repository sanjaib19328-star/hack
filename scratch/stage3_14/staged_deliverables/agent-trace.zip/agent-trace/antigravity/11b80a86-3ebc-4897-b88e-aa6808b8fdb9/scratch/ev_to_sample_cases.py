import os
import json
import csv
import pandas as pd
from collections import defaultdict

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

sample_outs = pd.read_csv(os.path.join(DATASET_DIR, "sample_output.csv"))
sample_reqs = pd.read_csv(os.path.join(DATASET_DIR, "sample_deletion_requests.csv"))
users = pd.read_csv(os.path.join(DATASET_DIR, "user_identities.csv"))
audit_log = pd.read_csv(os.path.join(DATASET_DIR, "user_audit_log.csv"))
ef = pd.read_csv(os.path.join(DATASET_DIR, "evidence_files.csv"))

email_to_uid = {}
for idx, r in users.iterrows():
    email_to_uid[r['email'].lower()] = r['user_id']
for idx, r in audit_log.iterrows():
    if pd.notna(r['old_value']) and '@' in str(r['old_value']):
        email_to_uid[str(r['old_value']).lower()] = r['user_id']
    if pd.notna(r['new_value']) and '@' in str(r['new_value']):
        email_to_uid[str(r['new_value']).lower()] = r['user_id']

# Group sample cases by the evidence file they cite
ev_to_cases = defaultdict(list)
for idx, r in sample_outs.iterrows():
    cid = r['case_id']
    steps = json.loads(r['steps_json'])
    evs = set(s['evidence_id'] for s in steps if s['evidence_id'])
    for e in evs:
        ev_to_cases[e].append(cid)

for e, cids in sorted(ev_to_cases.items()):
    ef_row = ef[ef['file_id'] == e].iloc[0]
    print(f"{e} ({ef_row['origin']}, {ef_row['file_path']}): covers {cids}")
