import os
import json
import pandas as pd
from collections import defaultdict

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

reqs = pd.read_csv(os.path.join(DATASET_DIR, "deletion_requests.csv"))
users = pd.read_csv(os.path.join(DATASET_DIR, "user_identities.csv"))
audit_log = pd.read_csv(os.path.join(DATASET_DIR, "user_audit_log.csv"))
ef = pd.read_csv(os.path.join(DATASET_DIR, "evidence_files.csv"))

email_to_uid = {}
for idx, r in users.iterrows():
    email_to_uid[r['email'].lower()] = r['user_id']
for idx, r in audit_log.iterrows():
    if pd.notna(r['old_value']) and '@' in str(r['old_value']):
        email_to_uid[str(r['old_value']).lower()] = r['user_id']
    if pd.notna(r['new_value']) and '@' in str(r['new_value']):
        email_to_uid[str(r['new_value']).lower()] = r['user_id']

reqs['user_id'] = reqs['email'].str.lower().map(email_to_uid)

# Check each case in deletion_requests:
# Which evidence file has captured_at <= audit_at closest to audit_at?
matched_files = defaultdict(list)
for idx, r in reqs.iterrows():
    cid = r['case_id']
    uid = r['user_id']
    aat = r['audit_at']
    # find evidence file
    sub = ef[ef['captured_at'] <= aat].sort_values('captured_at', ascending=False)
    if len(sub) > 0:
        top = sub.iloc[0]
        matched_files[top['file_id']].append((cid, uid))

print(f"Total evidence files matched across 518 cases: {len(matched_files)}")
for fid, cases in sorted(matched_files.items(), key=lambda x: len(x[1]), reverse=True)[:15]:
    ef_row = ef[ef['file_id'] == fid].iloc[0]
    print(f"{fid:12s} | count={len(cases):3d} | origin={ef_row['origin']:35s} | path={ef_row['file_path']}")
