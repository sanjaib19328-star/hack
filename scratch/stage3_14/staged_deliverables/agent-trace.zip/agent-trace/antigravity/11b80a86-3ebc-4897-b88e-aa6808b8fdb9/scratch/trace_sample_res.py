import csv
import json
import os
from collections import defaultdict

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

# Load sample output
with open(os.path.join(DATASET_DIR, "sample_output.csv"), "r", encoding="utf-8") as f:
    sample_outs = {r["case_id"]: json.loads(r["steps_json"]) for r in csv.DictReader(f)}

# Load sample requests
with open(os.path.join(DATASET_DIR, "sample_deletion_requests.csv"), "r", encoding="utf-8") as f:
    sample_reqs = {r["case_id"]: r for r in csv.DictReader(f)}

# Load user identities
with open(os.path.join(DATASET_DIR, "user_identities.csv"), "r", encoding="utf-8") as f:
    user_identities = list(csv.DictReader(f))

# Load user audit log
with open(os.path.join(DATASET_DIR, "user_audit_log.csv"), "r", encoding="utf-8") as f:
    user_audit = list(csv.DictReader(f))

# Load system activity
with open(os.path.join(DATASET_DIR, "system_activity.csv"), "r", encoding="utf-8") as f:
    system_activity = list(csv.DictReader(f))

# Build resource_id -> activities
res_to_act = defaultdict(list)
for act in system_activity:
    res_to_act[act["resource_id"]].append(act)

# Build email -> user_id, user_id -> all emails/phones/names
email_to_uid = {}
uid_to_emails = defaultdict(set)
uid_to_names = defaultdict(set)
uid_to_phones = defaultdict(set)
for u in user_identities:
    uid = u["user_id"]
    e = u["email"].lower()
    email_to_uid[e] = uid
    uid_to_emails[uid].add(e)
    if u.get("name"): uid_to_names[uid].add(u["name"].lower())
    if u.get("phone"): uid_to_phones[uid].add(u["phone"])

for a in user_audit:
    uid = a["user_id"]
    if a["field_name"] == "email":
        email_to_uid[a["old_value"].lower()] = uid
        uid_to_emails[uid].add(a["old_value"].lower())
        uid_to_emails[uid].add(a["new_value"].lower())
    elif a["field_name"] == "phone":
        uid_to_phones[uid].add(a["old_value"])
        uid_to_phones[uid].add(a["new_value"])
    elif a["field_name"] == "name":
        uid_to_names[uid].add(a["old_value"].lower())
        uid_to_names[uid].add(a["new_value"].lower())

print("Tracing sample resources to system_activity...")
for cid in sorted(sample_outs.keys(), key=lambda x: int(x.split("_")[1])):
    req = sample_reqs[cid]
    uid = email_to_uid.get(req["email"].lower())
    steps = sample_outs[cid]
    step_res = set(s["resource_id"] for s in steps)
    print(f"\n=== Case {cid} (uid={uid}, email={req['email']}, audit_at={req['audit_at']}) ===")
    for res in sorted(step_res):
        acts = res_to_act.get(res, [])
        act_types = [f"{a['event_type']}@{a['event_time']}({a['source_system']}->{a['target_system']}:{a['reported_result']})" for a in acts]
        print(f"  Resource {res}: {len(acts)} acts -> {act_types}")
