import csv
import json
import os

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

with open(os.path.join(DATASET_DIR, "deletion_requests.csv"), "r", encoding="utf-8") as f:
    full_reqs = list(csv.DictReader(f))

print(f"Total full deletion requests: {len(full_reqs)}")

# Sample a few request texts
for r in full_reqs[:15]:
    print(f"[{r['case_id']}] ({r['reported_status']}) {r['request_text']}")
