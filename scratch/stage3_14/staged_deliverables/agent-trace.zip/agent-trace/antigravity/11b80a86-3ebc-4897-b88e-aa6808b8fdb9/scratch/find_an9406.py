import os

for root, dirs, files in os.walk('hackerrank-orchestrate-october26-main/dataset/evidence'):
    for f in files:
        p = os.path.join(root, f)
        try:
            with open(p, 'r', encoding='utf-8', errors='ignore') as fh:
                content = fh.read()
                if 'analytics_9406' in content:
                    print(f"analytics_9406 in {f}")
        except: pass
