import pandas as pd
ef = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/evidence_files.csv')
ef_sorted = ef.sort_values('captured_at')
for idx, r in ef_sorted.iterrows():
    print(f"{r['captured_at']} | {r['file_id']:12s} | {r['origin']:40s} | {r['file_path']}")
