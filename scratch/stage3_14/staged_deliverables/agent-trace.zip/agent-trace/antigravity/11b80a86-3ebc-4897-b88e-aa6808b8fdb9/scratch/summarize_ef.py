import pandas as pd
ef = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/evidence_files.csv')
print(f"Total evidence files: {len(ef)}")
print("\nBy origin:")
print(ef['origin'].value_counts())
print("\nBy extension:")
print(ef['file_path'].apply(lambda x: x.split('.')[-1]).value_counts())
