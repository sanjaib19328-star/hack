import json
import pandas as pd

df = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_output.csv')
for i in range(10, 20):
    r = df.iloc[i]
    print(f"\n{r['case_id']}: {r['deletion_status']}")
    for s in json.loads(r['steps_json']):
        print(f"  {s['step_no']}: {s['phase']} | {s['system_id']} | {s['operation']} | {s['resource_id']} | {s['state']} | ev={s['evidence_id']}")
