import os
import csv
from collections import Counter

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

with open(os.path.join(DATASET_DIR, "system_activity.csv"), "r", encoding="utf-8") as f:
    sys_acts = list(csv.DictReader(f))

event_types = Counter(a["event_type"] for a in sys_acts)
print("Event types in system_activity.csv:")
for et, cnt in event_types.most_common():
    print(f"  {et}: {cnt}")

source_systems = Counter(a["source_system"] for a in sys_acts)
print("\nSource systems:")
for ss, cnt in source_systems.most_common():
    print(f"  {ss}: {cnt}")

target_systems = Counter(a["target_system"] for a in sys_acts)
print("\nTarget systems:")
for ts, cnt in target_systems.most_common():
    print(f"  {ts}: {cnt}")
