"""
Verify that every cited evidence file in sample_output.csv contains the user's identifier.
"""

import os
import csv
import json
from collections import defaultdict

repo_dir = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
dataset_dir = os.path.join(repo_dir, "dataset")

# Identity map
email_to_uid = {}
uid_to_emails = defaultdict(set)
with open(os.path.join(dataset_dir, "user_identities.csv"), encoding="utf-8") as f:
    for r in csv.DictReader(f):
        u = r["user_id"]
        e = r["email"].lower().strip()
        email_to_uid[e] = u
        uid_to_emails[u].add(e)

with open(os.path.join(dataset_dir, "user_audit_log.csv"), encoding="utf-8") as f:
    for r in csv.DictReader(f):
        u = r["user_id"]
        if r.get("field_name") == "email":
            if r.get("old_value"):
                e = r["old_value"].lower().strip()
                email_to_uid[e] = u
                uid_to_emails[u].add(e)
            if r.get("new_value"):
                e = r["new_value"].lower().strip()
                email_to_uid[e] = u
                uid_to_emails[u].add(e)

with open(os.path.join(dataset_dir, "evidence_files.csv"), encoding="utf-8") as f:
    ev_files = {r["file_id"]: r for r in csv.DictReader(f)}

with open(os.path.join(dataset_dir, "sample_deletion_requests.csv"), encoding="utf-8") as f:
    reqs = {r["case_id"]: r for r in csv.DictReader(f)}

with open(os.path.join(dataset_dir, "sample_output.csv"), encoding="utf-8") as f:
    sample_out = {r["case_id"]: (r["deletion_status"], json.loads(r["steps_json"])) for r in csv.DictReader(f)}

for cid, (st, steps) in sample_out.items():
    req = reqs[cid]
    req_email = req["email"].lower().strip()
    u = email_to_uid.get(req_email)
    all_emails = uid_to_emails.get(u, {req_email})
    
    cited_evs = set(s["evidence_id"] for s in steps if s["evidence_id"])
    for ev_id in cited_evs:
        ev_info = ev_files[ev_id]
        fpath = os.path.join(dataset_dir, ev_info["file_path"])
        ext = fpath.split(".")[-1].lower()
        content = ""
        if ext == "pdf":
            try:
                from pypdf import PdfReader
                reader = PdfReader(fpath)
                content = " ".join([page.extract_text() for page in reader.pages]).lower()
            except Exception:
                pass
        else:
            try:
                with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read().lower()
            except Exception:
                pass
                
        has_uid = (u and u.lower() in content) if u else False
        has_email = any(e in content for e in all_emails)
        
        # Also check if any step resource_id is in content
        step_res = set(s["resource_id"] for s in steps if s["evidence_id"] == ev_id)
        has_res = any(r.lower() in content for r in step_res)
        
        print(f"{cid} -> {ev_id} ({ev_info['origin']}): has_uid={has_uid}, has_email={has_email}, has_res={has_res}")
