import pandas as pd
import json

sample_reqs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_deletion_requests.csv')
sample_outs = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/sample_output.csv')
ef = pd.read_csv('hackerrank-orchestrate-october26-main/dataset/evidence_files.csv')

merged = pd.merge(sample_reqs, sample_outs, on='case_id')

for idx, r in merged.iterrows():
    aat = r['audit_at']
    steps = json.loads(r['steps_json'])
    expected_evs = set(s['evidence_id'] for s in steps if s['evidence_id'])
    
    # Latest evidence file captured at or before aat
    sub_ef = ef[(ef['captured_at'] <= aat)].sort_values('captured_at', ascending=False)
    latest_fid = sub_ef.iloc[0]['file_id'] if len(sub_ef) > 0 else "NONE"
    
    print(f"{r['case_id']}: audit_at={aat} | expected={expected_evs} | latest={latest_fid} | match={latest_fid in expected_evs}")
