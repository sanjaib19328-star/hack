import csv
import json
import os
import glob

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

print("Checking dataset files...")
for fname in os.listdir(DATASET_DIR):
    fpath = os.path.join(DATASET_DIR, fname)
    if os.path.isfile(fpath):
        print(f"  {fname}: {os.path.getsize(fpath)} bytes")

# Check sample_deletion_requests vs sample_output
sample_reqs = []
with open(os.path.join(DATASET_DIR, "sample_deletion_requests.csv"), "r", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    sample_reqs = list(reader)

sample_outs = {}
with open(os.path.join(DATASET_DIR, "sample_output.csv"), "r", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    for row in reader:
        sample_outs[row["case_id"]] = {
            "deletion_status": row["deletion_status"],
            "steps": json.loads(row["steps_json"])
        }

print(f"\nTotal sample requests: {len(sample_reqs)}, total sample outputs: {len(sample_outs)}")

# Analyze sample cases
for req in sample_reqs[:10]:
    cid = req["case_id"]
    email = req["email"]
    out = sample_outs.get(cid)
    print(f"\n--- {cid} ({email}) ---")
    print(f"  Req text: {req['request_text']}")
    print(f"  Reported status: {req['reported_status']}, audit_at: {req['audit_at']}")
    print(f"  Actual status: {out['deletion_status']}")
    print(f"  Steps ({len(out['steps'])}):")
    for s in out["steps"]:
        print(f"    Step {s['step_no']}: phase={s['phase']} sys={s['system_id']} res={s['resource_id']} op={s['operation']} st={s['state']} ev={s['evidence_id']}")
