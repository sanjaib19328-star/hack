import os
import json
import csv
import re
import pandas as pd
from collections import defaultdict

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

users_df = pd.read_csv(os.path.join(DATASET_DIR, "user_identities.csv"))
audit_df = pd.read_csv(os.path.join(DATASET_DIR, "user_audit_log.csv"))
ef_df = pd.read_csv(os.path.join(DATASET_DIR, "evidence_files.csv"))

email_to_uid = {}
for idx, r in users_df.iterrows():
    email_to_uid[r['email'].lower().strip()] = r['user_id']
for idx, r in audit_df.iterrows():
    if r['field_name'] == 'email':
        if pd.notna(r['old_value']): email_to_uid[r['old_value'].lower().strip()] = r['user_id']
        if pd.notna(r['new_value']): email_to_uid[r['new_value'].lower().strip()] = r['user_id']

user_to_account = {}

# 1. Search all evidence files
for idx, ev in ef_df.iterrows():
    fpath = os.path.join(DATASET_DIR, ev['file_path'])
    if not os.path.exists(fpath): continue
    ext = fpath.split('.')[-1].lower()
    
    if ext == 'json':
        try:
            with open(fpath, 'r', encoding='utf-8') as f:
                d = json.load(f)
            # Check service_exports
            if 'service_exports' in d:
                acc = d['service_exports'].get('account_service', {})
                for p in acc.get('profile_lookups', []):
                    rid = p.get('resource_id')
                    prof = p.get('profile') or {}
                    em = prof.get('email')
                    ref = prof.get('customer_reference')
                    uid = ref if ref else (email_to_uid.get(str(em).lower().strip()) if em else None)
                    if uid and rid and uid not in user_to_account:
                        user_to_account[uid] = rid
            # Check snapshots
            if 'snapshots' in d:
                for s in d['snapshots']:
                    if s.get('data_store') == 'account_service':
                        for rec in s.get('records', []):
                            rid = rec.get('resource_id')
                            ref = rec.get('customer_reference')
                            em = rec.get('email')
                            uid = ref if ref else (email_to_uid.get(str(em).lower().strip()) if em else None)
                            if uid and rid and uid not in user_to_account:
                                user_to_account[uid] = rid
        except Exception: pass

    elif ext == 'log':
        try:
            with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    if 'account_' in line:
                        m_rid = re.search(r'(account_\d+)', line)
                        m_em = re.search(r'[\w\.-]+@[\w\.-]+\.\w+', line)
                        m_uid = re.search(r'(user_\d+)', line)
                        rid = m_rid.group(1) if m_rid else None
                        uid = m_uid.group(1) if m_uid else (email_to_uid.get(m_em.group(0).lower()) if m_em else None)
                        if uid and rid and uid not in user_to_account:
                            user_to_account[uid] = rid
        except Exception: pass

    elif ext == 'sql':
        try:
            with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    if 'customer_profiles' in line and 'account_' in line:
                        m_rid = re.search(r'(account_\d+)', line)
                        m_em = re.search(r'[\w\.-]+@[\w\.-]+\.\w+', line)
                        m_uid = re.search(r'(user_\d+)', line)
                        rid = m_rid.group(1) if m_rid else None
                        uid = m_uid.group(1) if m_uid else (email_to_uid.get(m_em.group(0).lower()) if m_em else None)
                        if uid and rid and uid not in user_to_account:
                            user_to_account[uid] = rid
        except Exception: pass

print(f"Total mapped user accounts: {len(user_to_account)}")
