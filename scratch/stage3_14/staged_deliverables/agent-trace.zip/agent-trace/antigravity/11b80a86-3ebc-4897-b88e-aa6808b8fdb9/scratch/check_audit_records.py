import csv
import glob
import json
import os

REPO_DIR = r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main"
DATASET_DIR = os.path.join(REPO_DIR, "dataset")

with open(os.path.join(DATASET_DIR, "system_activity.csv"), "r", encoding="utf-8") as f:
    sys_acts = list(csv.DictReader(f))

audit_rec_acts = [a for a in sys_acts if a["resource_id"].startswith("audit_record_")]
print(f"Total audit_record activities in system_activity.csv: {len(audit_rec_acts)}")
for a in audit_rec_acts[:5]:
    print(a)
