import csv

with open(r"c:\Users\HP\Desktop\hackerrank_202610\hackerrank-orchestrate-october26-main\dataset\system_activity.csv", "r", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    for r in reader:
        s = str(r)
        if "user_27" in s or "ananya" in s or "account_3866" in s or "audit_record_3830" in s or "analytics_4574" in s:
            print(r)
